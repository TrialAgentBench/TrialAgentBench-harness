# Data specification

**Ariadne Clinical Research Collaborative**

| Document | Analysis data specification |
| --- | --- |
| Document ID | ACRC-DSPEC-7908E301 |
| Owner | Statistical Programming |
| Status | Approved |
| Effective milestone | Issued before the analysis transfer |
| Purpose | Define transferred tables, keys, variables, timing, and derivations. |
| Related document classes | Protocol summary, Statistical analysis plan, Data dictionary |

`participant_id` is the participant key. Event-history rows are ordered by participant, occurrence time, and event type. Times use the protocol follow-up scale.

## analysis.parquet

`participant_id` (int64), `occurrence_time` (float64), `outcome_id` (object), `attended` (bool), `measurement_obtained` (bool), `observed` (bool), `censoring_status` (object), `urine_albumin_creatinine_ratio` (float64), `assigned_arm` (object), `sex` (object), `type_2_diabetes` (object), `ras_blockade` (object), `site_id` (object), `country_code` (object), `enrollment_day` (float64), `consent_time` (float64), `age_years` (int64), `baseline_systolic_blood_pressure_mmhg` (float64), `baseline_egfr_ml_min_1_73m2` (float64), `baseline_body_mass_index` (float64), `baseline_haemoglobin` (float64), `baseline_uacr` (float64).

## participant_records.parquet

`participant_id` (int64), `sex` (object), `type_2_diabetes` (object), `ras_blockade` (object), `site_id` (object), `country_code` (object), `enrollment_day` (float64), `consent_time` (float64), `assigned_arm` (object), `completion_status` (object), `completion_time` (float64), `completion_observation_time` (float64), `completion_documentation_time` (float64), `completion_availability_time` (float64), `age_years` (int64), `baseline_systolic_blood_pressure_mmhg` (float64), `baseline_egfr_ml_min_1_73m2` (float64), `baseline_body_mass_index` (float64), `baseline_haemoglobin` (float64), `baseline_uacr` (float64).

## event_history.parquet

`participant_id` (int64), `ascertainment_contact_time` (float64), `occurrence_time` (float64), `observation_time` (float64), `documentation_time` (float64), `event_id` (object), `event_kind` (object), `event_type` (object), `availability_time` (float64), `event_at_contact` (bool), `event_by_contact` (bool), `first_event_time` (float64), `withdrawal_reason` (object), `withdrawal_reason_text` (object), `episode_id` (object), `medical_code` (object), `coding_system` (object), `dictionary_term` (object), `category` (object), `severity` (object), `serious` (object), `seriousness_criteria` (object), `reported` (object), `ascertainment` (object), `resolution_time` (float64), `exposure_action_applied` (bool).

## exposure_records.parquet

`participant_id` (int64), `occurrence_time` (float64), `received_arm` (object), `availability_time` (float64).

## endpoint_observations.parquet

`participant_id` (int64), `occurrence_time` (float64), `outcome_id` (object), `attended` (bool), `measurement_obtained` (bool), `observed` (bool), `censoring_status` (object), `urine_albumin_creatinine_ratio` (float64).
