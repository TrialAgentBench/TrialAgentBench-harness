# Protocol summary

**Ariadne Clinical Research Collaborative**

| Document | Protocol summary |
| --- | --- |
| Document ID | ACRC-PROT-D70EB734 |
| Owner | Clinical Science |
| Status | Approved |
| Effective milestone | Approved before participant enrolment |
| Purpose | Define the clinical question, study design, population, interventions, endpoints, and follow-up. |
| Related document classes | Statistical analysis plan, Source-data quality plan |

Study: Cascade kidney-disease monitoring trial.

Therapeutic area: nephrology.

Clinical setting: albuminuria reduction in chronic kidney disease.

Population: adults with chronic kidney disease and persistent albuminuria.

Study design: parallel group.

Target population: all randomized participants.

Treatment groups: add-on kidney-protection therapy versus usual kidney-protection care.

Primary endpoint: urine albumin-to-creatinine ratio through Day 365 by the protocol horizon.

Endpoint definition: Central-laboratory urine albumin-to-creatinine ratio recorded during protocol follow-up; the primary contrast is evaluated at Day 365.

Safety endpoint: Hyperkalaemia requiring treatment.

Safety endpoint definition: Protocol-defined hyperkalaemia requiring treatment through Day 365. The protocol serious-event category comprises episodes requiring inpatient admission or prolongation of an existing admission. Seriousness is recorded separately from intensity grade.

Primary estimand: marginal urine albumin creatinine ratio mean difference.

Planned sample size: 128 participants, derived from the prespecified information requirements.

This is a complete-report final extract: biological endpoint windows and the randomized cohort are fixed. The extract freezes no earlier than planned closeout and after all reports are available, including finalized missing/attendance status. Waiting does not impute missing measurements or recover additional endpoints.

Planned operations closeout: programme day 915.250000. Actual extract freeze: programme day 915.250000.

Follow-up: 365 days.

Study opening date: 2024-01-01.

Protocol epochs: TREATMENT, days 0–365.

Follow-up and endpoint ascertainment: The extract retains the randomized cohort, recorded endpoint assessments and follow-up records. Occurrence, assessment and reporting times have distinct meanings. Participants without a recorded endpoint remain in the cohort; absence of a record does not itself establish absence of an event.

Treatment discontinuation: assigned active study therapy stops and usual kidney-protection care continues. Outcome follow-up continues after the treatment change under the protocol estimand.

Treatment switch: received treatment follows the recorded treatment history. Outcome follow-up continues after the treatment change under the protocol estimand.

Treatment assignment is analyzed according to the declared estimand. Treatment-use events, follow-up termination, missing observations, and safety outcomes retain separate meanings.
