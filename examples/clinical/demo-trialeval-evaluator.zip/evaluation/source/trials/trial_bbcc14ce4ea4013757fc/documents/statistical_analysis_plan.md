# Statistical analysis plan

**Ariadne Clinical Research Collaborative**

| Document | Statistical analysis plan |
| --- | --- |
| Document ID | ACRC-SAP-D70EB734 |
| Owner | Biostatistics |
| Status | Approved |
| Effective milestone | Finalized before database lock and unblinding |
| Purpose | Prespecify the estimand, primary analysis, uncertainty procedure, diagnostics, and reporting. |
| Related document classes | Protocol summary, Analysis data specification, Statistical analysis request |

Primary objective: What is the kidney-protection-therapy minus usual-care mean difference in albuminuria at Day 365 when all recorded follow-up measurements are analysed?

The treatment contrast is add-on kidney-protection therapy minus usual kidney-protection care. The independent unit is the randomized participant.

Prespecified primary method: Fit a Gaussian marginal GEE containing an intercept, randomized-arm indicator, continuous `occurrence_time` in days, and their interaction. Use an exchangeable working correlation and participant-clustered sandwich uncertainty. Include no higher-order time term, spline term, or additional covariate. Evaluate the active-minus-control contrast at Day 365. The prespecified uncertainty procedure is participant-clustered sandwich standard error.

Describe the analysis used and any supported alternative in the report.

Prespecified diagnostic: Tabulate observed endpoint records by randomized arm and follow-up stratum. Use exact recorded times when there are at most 12; otherwise use four equal-width intervals over the declared follow-up. Report maximum_arm_observation_fraction_difference, minimum_observation_fraction, overall_observation_fraction, and time_stratum_count with the declared units. Interpret these as descriptive measures without a universal pass/fail cutoff. Report the result on the visit specific observation fraction scale. report observed and missing counts by randomized arm and scheduled or recorded time; no universal categorical severity cutoff

Prespecified diagnostic: Fit the declared repeated-measures mean model to complete endpoint records and standardize residuals by their root-mean-square scale. Use exact recorded times when there are at most 12; otherwise use four equal-width intervals over follow-up. Report maximum_absolute_cell_standardized_residual_mean by arm and time, absolute_residual_fitted_value_correlation, absolute_residual_time_correlation, standardized_residual_standard_deviation, and complete_record_count. Interpret these as descriptive measures without a universal pass/fail cutoff. Report the result on the standardized residual pattern scale. report residual location and spread across fitted values, randomized arms, and follow-up time; no universal categorical severity cutoff

Use an analysis supported by the randomized design and observed follow-up. Assess assumptions that could change the estimate or its uncertainty, and use a supported alternative or sensitivity analysis when the prespecified analysis is not adequate. Report the treatment-effect estimate and a 95% confidence interval. Explain any sensitivity analyses separately and the uncertainty they address. Report diagnostics and the practical interpretation.
