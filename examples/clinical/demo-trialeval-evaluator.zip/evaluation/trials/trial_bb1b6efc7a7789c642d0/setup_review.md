# Setup review: TE-S13 / trial_bb1b6efc7a7789c642d0

Review the corresponding participant packet before opening this construction reveal. Judge whether its question, evidence and clinical assumptions form a fair analysis task. You are not asked to reconstruct patients or reproduce the reference analysis.

Scenario: `scenario_9c7ab807d12ed80c7cd2a523438486f4960d441c3d5f47c2d6820a16ba25e92f`; executable digest: `49767bac80dd5f63ff1c0a6dda04da6f5f5207d6f5a608762c79097a1fa129d6`.

Cascade kidney-disease monitoring trial: albuminuria reduction in chronic kidney disease.

Population: adults with chronic kidney disease and persistent albuminuria. Compare add-on kidney-protection therapy with usual kidney-protection care. Endpoint: Central-laboratory urine albumin-to-creatinine ratio recorded during protocol follow-up; the primary contrast is evaluated at Day 365.

The question asks for `mean_difference` in `mg/g` at day 365, with 380 planned participants. Identification: `point_identified`.

Modelled treatment-use events: none. Modelled safety events: hyperkalaemia.

Construction rule: specify the clinical world, question and observation process; generate their shared history; grade the declared target under the information supplied. D describes the trial design, A the information conditions and C the assistance supplied. Their labels do not replace the numerical specifications below. Compatible reference analyses are qualification controls, not a requirement to use that estimator unless the task explicitly asks for its SAP analysis.

Baseline recording precedes downstream clinical and censoring mechanisms. Their nonlatent baseline parents are the recorded values expressed in the model's source units; unrounded precursors do not remain hidden common causes. Fixed reference scales standardize prognostic effects without recentering each trial. Changing a baseline recording rule therefore changes the declared world, whereas withholding an already generated measurement changes information.

Event intercepts parameterize conditional probabilities per eligible clinical opportunity. They are not cumulative incidences. `at_contact` denotes a contact-triggered action; `within_contact_interval` allocates an occurrence within the declared clinical interval. This discrete interval model does not claim a continuous-time hazard. Observation and availability govern which measurements can be used and when; they do not redefine treatment.

Scope of this longitudinal case: No separate rescue, switching or discontinuation trajectory is modelled. The assigned-intervention contrast is evaluated under that restriction; the case does not establish a per-protocol or hypothetical treatment-use effect. No separate disease-state process is claimed: outcome heterogeneity and temporal dependence are limited to the declared predictors, events and residual law. The purpose is to test inference for the specified endpoint and information, not to reproduce the indication's complete natural history. A competing cause, additional treatment trajectory or observation mechanism cannot be assumed present unless the native definition includes it.

Endpoints are modelled at the protocol-defined resolution. A composite diagnosis, confirmed event or sustained-response indicator can be one endpoint process; its component diagnoses, confirmation visits or daily symptoms are not implicitly simulated. These cases support analysis of the released endpoint records, not validation of an unmodelled diagnostic pathway.

An empty process list means that process is absent from this declared model. It is not evidence that the corresponding real-world event is impossible. Numerical assumptions are mechanism-relative unless their provenance explicitly supplies an empirical source. Assess joint plausibility, identification and task fairness; passing software checks is not clinical endorsement.

<details><summary>Question and identification: exact native definition</summary>

```json
[
  {
    "analysis_plan": {
      "alternatives": [],
      "primary": {
        "assumptions": [
          "mean_model",
          "missing_at_random"
        ],
        "categorical_covariates": [],
        "covariates": [],
        "estimand_sha256": "a03e9ab875fb63067cceb53600e046858bb1bc9a09ed43ceb934119f4c9b6354",
        "method_id": "repeated_measures",
        "question_sha256": "823c16b1108023a4f488970630b57a241c3aecf01abbd710e17ec09c3435a446",
        "required_diagnostics": [
          "model_residuals",
          "missingness_pattern"
        ],
        "sensitivity_analyses": [],
        "uncertainty_method": "sandwich"
      },
      "question_sha256": "823c16b1108023a4f488970630b57a241c3aecf01abbd710e17ec09c3435a446",
      "schema_version": "ariadne.prospective-analysis-plan/v1"
    },
    "analysis_question": {
      "design": "parallel_group",
      "effect_measure": "mean_difference",
      "endpoint_family": "longitudinal",
      "estimand": {
        "analysis_population": "intention_to_treat",
        "control_arm": "control",
        "endpoint_time": 365.0,
        "estimand_id": "marginal_urine_albumin_creatinine_ratio_mean_difference",
        "identification_assumptions": [],
        "identification_method": "observed_data_derivation",
        "identification_status": "point_identified",
        "intercurrent_event_strategies": [],
        "outcome_id": "urine_albumin_creatinine_ratio",
        "protocol_deviation_event_ids": [],
        "sensitivity_parameters": [],
        "supported_analysis_methods": [],
        "treatment_arm": "active"
      },
      "independent_unit": "participant",
      "observation_process": "missing_at_random",
      "violated_assumptions": []
    },
    "analysis_routes": [
      {
        "assumptions": [
          "mean_model",
          "missing_at_random"
        ],
        "method_id": "repeated_measures",
        "required_diagnostics": [
          "model_residuals",
          "missingness_pattern"
        ]
      },
      {
        "assumptions": [
          "missing_at_random"
        ],
        "method_id": "multiple_imputation_under_declared_model",
        "required_diagnostics": [
          "missingness_pattern"
        ]
      }
    ],
    "assessment_time": 365.0,
    "cluster_survival_analysis": null,
    "control_arm": "control",
    "effect_measure": "mean_difference",
    "endpoint_id": "urine_albumin_creatinine_ratio",
    "endpoint_kind": "longitudinal",
    "estimand_id": "marginal_urine_albumin_creatinine_ratio_mean_difference",
    "excluded_methods": [],
    "group_sequential_plan": null,
    "identification_assumptions": [],
    "identification_status": "point_identified",
    "identified_set": null,
    "longitudinal_time_model": "linear",
    "planning_question": null,
    "population_eligibility": [],
    "safety_event_ids": [],
    "stepped_wedge_analysis": null,
    "target_population": "all randomized participants",
    "treatment_arm": "active",
    "validation_analysis": null,
    "weighted_log_rank": null
  }
]
```

</details>

<details><summary>Planning assumptions: exact native definition</summary>

```json
{
  "allocation_multiple": 4,
  "maximum_subjects": 476,
  "minimum_subjects": 380,
  "plan_id": "te_s13_cohort_v1",
  "requirements": [
    {
      "design_request": {
        "design_type": "continuous",
        "outcome_standard_deviation": 134.66407864998737,
        "outcome_unit": "mg/g",
        "power": 0.9,
        "request_id": "te_s13_primary_endpoint",
        "treatment_allocation": 0.5,
        "treatment_difference": -45.0,
        "two_sided_alpha": 0.05
      },
      "evidence_scope": "single_trial",
      "rationale": "Minimum cohort from the prespecified normal_mean_difference design with 90% power and two-sided 5% alpha. The final-endpoint variance uses the declared residual variance and a Cauchy\u2013Schwarz bound on baseline and state contributions, with measurement rounding included. Planning assumptions: normal mean approximation. Achieved information requires simulation qualification.",
      "requirement_id": "primary_endpoint_information",
      "requirement_type": "derived_minimum_subjects"
    }
  ],
  "schema_id": "ariadne.trial_cohort_size_plan/v1",
  "selected_subjects": 380
}
```

</details>

<details><summary>Population: exact native definition</summary>

```json
{
  "contract_type": "simulation_design",
  "dependence": [
    {
      "dependence_id": "kidney_baseline_population",
      "dependence_type": "hierarchical_random_intercept",
      "group_root_seed": null,
      "group_variable": "site_id",
      "marginal_dependence": {
        "attainment_tolerance": 0.01,
        "dependence_id": "kidney_baseline_population",
        "dependence_type": "gaussian_copula",
        "meaning": "unconditional",
        "metric": "latent_gaussian",
        "reference_population": "adults with chronic kidney disease and persistent albuminuria",
        "scale": "latent",
        "target_matrix": [
          [
            0.9999999999999999,
            0.10467191248588766,
            -0.26105238444010315,
            -0.049999999999999996,
            0.34962504891460416,
            0.010467191248588767,
            -0.08429921312711684,
            -0.1913683345540361,
            0.11230271705121363
          ],
          [
            0.10467191248588766,
            0.9999999999999999,
            -0.1569181914556899,
            -0.005233595624294383,
            0.1549393024641198,
            0.09999999999999999,
            0.13953280875141122,
            -0.06538855825808022,
            0.2549213670094914
          ],
          [
            -0.26105238444010315,
            -0.1569181914556899,
            0.9999999999999999,
            0.013052619222005159,
            -0.2440075344775999,
            -0.01569181914556899,
            0.0025675097256568353,
            0.3761052384440103,
            -0.3813836382911379
          ],
          [
            -0.049999999999999996,
            -0.005233595624294383,
            0.013052619222005159,
            1.0,
            -0.01748125244573021,
            -0.0005233595624294384,
            0.004214960656355842,
            0.009568416727701805,
            -0.005615135852560682
          ],
          [
            0.34962504891460416,
            0.1549393024641198,
            -0.2440075344775999,
            -0.01748125244573021,
            1.0,
            0.01549393024641198,
            -0.011721609521842449,
            -0.12036514195862037,
            0.11639049755998392
          ],
          [
            0.010467191248588767,
            0.09999999999999999,
            -0.01569181914556899,
            -0.0005233595624294384,
            0.015493930246411979,
            1.0,
            0.013953280875141121,
            -0.006538855825808023,
            0.025492136700949148
          ],
          [
            -0.08429921312711684,
            0.13953280875141122,
            0.0025675097256568353,
            0.004214960656355842,
            -0.011721609521842454,
            0.013953280875141123,
            1.0,
            0.009328549716691576,
            0.027007933346302353
          ],
          [
            -0.1913683345540361,
            -0.06538855825808022,
            0.3761052384440103,
            0.009568416727701805,
            -0.1203651419586204,
            -0.006538855825808022,
            0.009328549716691576,
            1.0,
            -0.14471454510701964
          ],
          [
            0.11230271705121363,
            0.2549213670094914,
            -0.3813836382911379,
            -0.005615135852560682,
            0.11639049755998392,
            0.025492136700949145,
            0.027007933346302346,
            -0.14471454510701962,
            1.0
          ]
        ],
        "unit": "latent correlation",
        "variables": [
          "age",
          "baseline_risk",
          "bmi",
          "sex_code",
          "type_2_diabetes",
          "ras_blockade",
          "body_mass_index",
          "haemoglobin",
          "uacr"
        ]
      },
      "random_effect_correlation": [
        [
          1.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0
        ],
        [
          0.0,
          1.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0
        ],
        [
          0.0,
          0.0,
          1.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0
        ],
        [
          0.0,
          0.0,
          0.0,
          1.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0
        ],
        [
          0.0,
          0.0,
          0.0,
          0.0,
          1.0,
          0.0,
          0.0,
          0.0,
          0.0
        ],
        [
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          1.0,
          0.0,
          0.0,
          0.0
        ],
        [
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          1.0,
          0.0,
          0.0
        ],
        [
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          1.0,
          0.0
        ],
        [
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          1.0
        ]
      ],
      "residual_correlation": null,
      "scale": "latent",
      "targets": [
        {
          "intraclass_correlation": 0.0225,
          "variable": "age"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "baseline_risk"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "bmi"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "sex_code"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "type_2_diabetes"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "ras_blockade"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "body_mass_index"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "haemoglobin"
        },
        {
          "intraclass_correlation": 0.0225,
          "variable": "uacr"
        }
      ]
    }
  ],
  "entities": [],
  "features": [
    {
      "encoding": "numeric",
      "quantity": {
        "absolute_tolerance": 1e-10,
        "family": "truncated_normal",
        "lower": 30.0,
        "mean": 64.0,
        "quantity_type": "moment_target",
        "trials": null,
        "unit": "years",
        "upper": 88.0,
        "variance": 121.0
      },
      "role": "baseline",
      "variable_id": "age"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "absolute_tolerance": 1e-10,
        "family": "truncated_normal",
        "lower": 70.0,
        "mean": 138.0,
        "quantity_type": "moment_target",
        "trials": null,
        "unit": "clinical units",
        "upper": 240.0,
        "variance": 144.0
      },
      "role": "baseline",
      "variable_id": "baseline_risk"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "absolute_tolerance": 1e-10,
        "family": "truncated_normal",
        "lower": 7.5,
        "mean": 21.0,
        "quantity_type": "moment_target",
        "trials": null,
        "unit": "kg/m2",
        "upper": 37.5,
        "variance": 42.25
      },
      "role": "baseline",
      "variable_id": "bmi"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "absolute_tolerance": 1e-10,
        "family": "normal",
        "lower": null,
        "mean": 0.0,
        "quantity_type": "moment_target",
        "trials": null,
        "unit": "standard deviations",
        "upper": null,
        "variance": 1.0
      },
      "role": "baseline",
      "variable_id": "latent_followup_risk"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "distribution": {
          "family": "bernoulli",
          "probability": 0.33108736059479554
        },
        "quantity_type": "analytic_numeric_distribution",
        "unit": "indicator"
      },
      "role": "baseline",
      "variable_id": "sex_code"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "distribution": {
          "family": "bernoulli",
          "probability": 0.675185873605948
        },
        "quantity_type": "analytic_numeric_distribution",
        "unit": "indicator"
      },
      "role": "baseline",
      "variable_id": "type_2_diabetes"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "distribution": {
          "family": "bernoulli",
          "probability": 0.9697955390334573
        },
        "quantity_type": "analytic_numeric_distribution",
        "unit": "indicator"
      },
      "role": "baseline",
      "variable_id": "ras_blockade"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "absolute_tolerance": 1e-10,
        "family": "truncated_normal",
        "lower": 15.0,
        "mean": 29.5,
        "quantity_type": "moment_target",
        "trials": null,
        "unit": "kg/m2",
        "upper": 55.0,
        "variance": 38.440000000000005
      },
      "role": "baseline",
      "variable_id": "body_mass_index"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "absolute_tolerance": 1e-10,
        "family": "truncated_normal",
        "lower": 60.0,
        "mean": 128.3,
        "quantity_type": "moment_target",
        "trials": null,
        "unit": "g/L",
        "upper": 190.0,
        "variance": 327.61000000000007
      },
      "role": "baseline",
      "variable_id": "haemoglobin"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "distribution": {
          "family": "log_normal",
          "log_mean": 6.8557248708877525,
          "log_standard_deviation": 1.0
        },
        "quantity_type": "analytic_numeric_distribution",
        "unit": "mg/g"
      },
      "role": "baseline",
      "variable_id": "uacr"
    },
    {
      "encoding": "label",
      "quantity": {
        "levels": [
          "USA",
          "CAN",
          "GBR",
          "DEU"
        ],
        "probabilities": [
          0.25,
          0.25,
          0.25,
          0.25
        ],
        "quantity_type": "categorical_distribution"
      },
      "role": "baseline",
      "variable_id": "country_code"
    },
    {
      "encoding": "label",
      "quantity": {
        "distributions": [
          {
            "levels": [
              "site_001",
              "site_005",
              "site_009",
              "site_013",
              "site_017",
              "site_021"
            ],
            "parent_level": "USA",
            "probabilities": [
              0.08333333333333334,
              0.16666666666666669,
              0.25,
              0.08333333333333334,
              0.16666666666666669,
              0.25
            ]
          },
          {
            "levels": [
              "site_002",
              "site_006",
              "site_010",
              "site_014",
              "site_018",
              "site_022"
            ],
            "parent_level": "CAN",
            "probabilities": [
              0.16666666666666669,
              0.25,
              0.08333333333333334,
              0.16666666666666669,
              0.25,
              0.08333333333333334
            ]
          },
          {
            "levels": [
              "site_003",
              "site_007",
              "site_011",
              "site_015",
              "site_019",
              "site_023"
            ],
            "parent_level": "GBR",
            "probabilities": [
              0.25,
              0.08333333333333334,
              0.16666666666666669,
              0.25,
              0.08333333333333334,
              0.16666666666666669
            ]
          },
          {
            "levels": [
              "site_004",
              "site_008",
              "site_012",
              "site_016",
              "site_020",
              "site_024"
            ],
            "parent_level": "DEU",
            "probabilities": [
              0.08333333333333334,
              0.16666666666666669,
              0.25,
              0.08333333333333334,
              0.16666666666666669,
              0.25
            ]
          }
        ],
        "parent_variable": "country_code",
        "quantity_type": "nested_categorical_distribution"
      },
      "role": "baseline",
      "variable_id": "site_id"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "quantity_type": "deferred",
        "reason": "derive_from_parent",
        "resolution_stage": "bmi_curve_mechanism",
        "unit": "standardized BMI contribution"
      },
      "role": "derived",
      "variable_id": "bmi_curve"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "quantity_type": "deferred",
        "reason": "derive_from_parent",
        "resolution_stage": "site_outcome_context_mechanism",
        "unit": "standard deviations"
      },
      "role": "derived",
      "variable_id": "site_outcome_context"
    },
    {
      "encoding": "numeric",
      "quantity": {
        "quantity_type": "deferred",
        "reason": "derive_from_parent",
        "resolution_stage": "primary_log_hazard_mechanism",
        "unit": "log hazard"
      },
      "role": "derived",
      "variable_id": "primary_log_hazard"
    }
  ],
  "materializations": [
    {
      "format": "parquet",
      "kind": "participant_table",
      "materialization_id": "foundation",
      "variables": [
        "age",
        "baseline_risk",
        "bmi",
        "latent_followup_risk",
        "sex_code",
        "type_2_diabetes",
        "ras_blockade",
        "body_mass_index",
        "haemoglobin",
        "uacr",
        "country_code",
        "site_id",
        "bmi_curve",
        "site_outcome_context",
        "primary_log_hazard"
      ]
    }
  ],
  "mechanisms": [
    {
      "effects": [
        {
          "center": 21.0,
          "coefficient": -1.0,
          "effect_id": "bmi_curve_power_1",
          "effect_type": "standardized_polynomial",
          "input_variable": "bmi",
          "power": 1,
          "scale": 6.5,
          "unit": "standardized BMI contribution"
        }
      ],
      "hierarchical_effect_correlations": [],
      "inputs": [
        "bmi"
      ],
      "learned": null,
      "measurement_model": null,
      "mechanism_id": "bmi_curve_mechanism",
      "mechanism_type": "derived_effect",
      "nominal_calibration": null,
      "nominal_logits": null,
      "observation_rule": null,
      "output": "bmi_curve",
      "output_levels": null,
      "output_unit": "standardized BMI contribution",
      "parameters": [
        {
          "input_variable": null,
          "parameter_id": "bmi_curve_intercept",
          "role": "intercept",
          "source": "fixed",
          "unit": "standardized BMI contribution",
          "value": 0.0
        }
      ],
      "probability_bounds": null,
      "residual_scale": null,
      "stochastic": false
    },
    {
      "effects": [
        {
          "effect_id": "site_outcome_intercept",
          "effect_type": "hierarchical",
          "group_root_seed": null,
          "grouping_variable": "site_id",
          "input_variable": null,
          "mean": 0.0,
          "standard_deviation": 1.0,
          "unit": "standard deviations"
        }
      ],
      "hierarchical_effect_correlations": [],
      "inputs": [
        "site_id"
      ],
      "learned": null,
      "measurement_model": null,
      "mechanism_id": "site_outcome_context_mechanism",
      "mechanism_type": "derived_effect",
      "nominal_calibration": null,
      "nominal_logits": null,
      "observation_rule": null,
      "output": "site_outcome_context",
      "output_levels": null,
      "output_unit": "standard deviations",
      "parameters": [
        {
          "input_variable": null,
          "parameter_id": "site_outcome_intercept_mean",
          "role": "intercept",
          "source": "fixed",
          "unit": "standard deviations",
          "value": 0.0
        }
      ],
      "probability_bounds": null,
      "residual_scale": null,
      "stochastic": false
    },
    {
      "effects": [
        {
          "center": 64.0,
          "coefficient": 0.15,
          "effect_id": "primary_age_log_hazard",
          "effect_type": "standardized_polynomial",
          "input_variable": "age",
          "power": 1,
          "scale": 11.0,
          "unit": "log hazard"
        },
        {
          "center": 138.0,
          "coefficient": 0.2,
          "effect_id": "primary_secondary_baseline_log_hazard",
          "effect_type": "standardized_polynomial",
          "input_variable": "baseline_risk",
          "power": 1,
          "scale": 12.0,
          "unit": "log hazard"
        },
        {
          "coefficient": 1.0,
          "effect_id": "primary_prognostic_log_hazard",
          "effect_type": "main",
          "input_variable": "bmi_curve",
          "unit": "log hazard"
        }
      ],
      "hierarchical_effect_correlations": [],
      "inputs": [
        "age",
        "baseline_risk",
        "bmi_curve"
      ],
      "learned": null,
      "measurement_model": null,
      "mechanism_id": "primary_log_hazard_mechanism",
      "mechanism_type": "derived_effect",
      "nominal_calibration": null,
      "nominal_logits": null,
      "observation_rule": null,
      "output": "primary_log_hazard",
      "output_levels": null,
      "output_unit": "log hazard",
      "parameters": [
        {
          "input_variable": null,
          "parameter_id": "primary_log_hazard_intercept",
          "role": "intercept",
          "source": "fixed",
          "unit": "log hazard",
          "value": 0.0
        }
      ],
      "probability_bounds": null,
      "residual_scale": null,
      "stochastic": false
    }
  ],
  "outcomes": [],
  "population": {
    "independent_unit": "participant",
    "reference_population": "adults with chronic kidney disease and persistent albuminuria",
    "size": 380
  },
  "population_selection": null,
  "product": "foundation",
  "quantity_accounts": [],
  "random_stream_id": null,
  "relationships": [],
  "residual_dependence": [],
  "root_seed": 3316684032844371484,
  "schema_version": "ariadne.simulation-design/v1"
}
```

</details>

<details><summary>Baseline measurement: exact native definition</summary>

```json
[
  {
    "allowed_values": null,
    "categories": [],
    "evidence_role": "mechanism_relative",
    "family": "demographic",
    "field_id": "age_years",
    "label": "Age at randomisation",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Age at the trial time origin, recorded in completed years",
      "missing_value": "",
      "resolution": 1.0
    },
    "offset": 0.0,
    "role": "demographic covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [],
    "source_direction": 1,
    "source_field_id": "age",
    "source_ids": [],
    "support": {
      "lower": 30.0,
      "upper": 88.0
    },
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "years",
    "value_type": "integer"
  },
  {
    "allowed_values": null,
    "categories": [],
    "evidence_role": "mechanism_relative",
    "family": "vital_sign",
    "field_id": "baseline_systolic_blood_pressure_mmhg",
    "label": "Systolic blood pressure at randomization",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Protocol-specified baseline assessment",
      "missing_value": "",
      "resolution": 1.0
    },
    "offset": 0.0,
    "role": "baseline covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [],
    "source_direction": 1,
    "source_field_id": "baseline_risk",
    "source_ids": [],
    "support": {
      "lower": 70.0,
      "upper": 240.0
    },
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "mmHg",
    "value_type": "continuous"
  },
  {
    "allowed_values": null,
    "categories": [],
    "evidence_role": "mechanism_relative",
    "family": "laboratory",
    "field_id": "baseline_egfr_ml_min_1_73m2",
    "label": "Estimated glomerular filtration rate at randomization",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Protocol-specified prognostic assessment at the trial time origin",
      "missing_value": "",
      "resolution": 1.0
    },
    "offset": 0.0,
    "role": "prognostic covariate",
    "scale": 2.0,
    "settings": [
      "trial"
    ],
    "source_codes": [],
    "source_direction": 1,
    "source_field_id": "bmi",
    "source_ids": [],
    "support": {
      "lower": 15.0,
      "upper": 75.0
    },
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "mL/min/1.73 m2",
    "value_type": "continuous"
  },
  {
    "allowed_values": null,
    "categories": [
      "male",
      "female"
    ],
    "evidence_role": "empirical_calibration",
    "family": "demographic",
    "field_id": "sex",
    "label": "Recorded sex",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Baseline clinical record",
      "missing_value": "",
      "resolution": null
    },
    "offset": 0.0,
    "role": "baseline context covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [
      0.0,
      1.0
    ],
    "source_direction": 1,
    "source_field_id": "sex_code",
    "source_ids": [
      "TAB-SRC-080"
    ],
    "support": null,
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "category",
    "value_type": "categorical"
  },
  {
    "allowed_values": null,
    "categories": [
      "no",
      "yes"
    ],
    "evidence_role": "empirical_calibration",
    "family": "disease_measure",
    "field_id": "type_2_diabetes",
    "label": "Type 2 diabetes at baseline",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Baseline clinical record",
      "missing_value": "",
      "resolution": null
    },
    "offset": 0.0,
    "role": "baseline context covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [
      0.0,
      1.0
    ],
    "source_direction": 1,
    "source_field_id": "type_2_diabetes",
    "source_ids": [
      "TAB-SRC-080"
    ],
    "support": null,
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "category",
    "value_type": "categorical"
  },
  {
    "allowed_values": null,
    "categories": [
      "no",
      "yes"
    ],
    "evidence_role": "empirical_calibration",
    "family": "treatment",
    "field_id": "ras_blockade",
    "label": "Renin-angiotensin system blockade at baseline",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Baseline clinical record",
      "missing_value": "",
      "resolution": null
    },
    "offset": 0.0,
    "role": "baseline context covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [
      0.0,
      1.0
    ],
    "source_direction": 1,
    "source_field_id": "ras_blockade",
    "source_ids": [
      "TAB-SRC-080"
    ],
    "support": null,
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "category",
    "value_type": "categorical"
  },
  {
    "allowed_values": null,
    "categories": [],
    "evidence_role": "mechanism_relative",
    "family": "anthropometric",
    "field_id": "baseline_body_mass_index",
    "label": "Body mass index at baseline",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Baseline clinical measurement",
      "missing_value": "",
      "resolution": 0.1
    },
    "offset": 0.0,
    "role": "baseline proxy covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [],
    "source_direction": 1,
    "source_field_id": "body_mass_index",
    "source_ids": [
      "TAB-SRC-080"
    ],
    "support": {
      "lower": 15.0,
      "upper": 55.0
    },
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "kg/m2",
    "value_type": "continuous"
  },
  {
    "allowed_values": null,
    "categories": [],
    "evidence_role": "mechanism_relative",
    "family": "laboratory",
    "field_id": "baseline_haemoglobin",
    "label": "Haemoglobin at baseline",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Baseline clinical measurement",
      "missing_value": "",
      "resolution": 0.1
    },
    "offset": 0.0,
    "role": "baseline proxy covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [],
    "source_direction": 1,
    "source_field_id": "haemoglobin",
    "source_ids": [
      "TAB-SRC-080"
    ],
    "support": {
      "lower": 60.0,
      "upper": 190.0
    },
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "g/L",
    "value_type": "continuous"
  },
  {
    "allowed_values": null,
    "categories": [],
    "evidence_role": "mechanism_relative",
    "family": "laboratory",
    "field_id": "baseline_uacr",
    "label": "Urine albumin-to-creatinine ratio at baseline",
    "measurement": {
      "artifact_modes": [],
      "device_or_assay": null,
      "error": {
        "error_model": "exact"
      },
      "method": "Baseline clinical measurement",
      "missing_value": "",
      "resolution": 0.1
    },
    "offset": 0.0,
    "role": "baseline proxy covariate",
    "scale": 1.0,
    "settings": [
      "trial"
    ],
    "source_codes": [],
    "source_direction": 1,
    "source_field_id": "uacr",
    "source_ids": [
      "TAB-SRC-080"
    ],
    "support": {
      "lower": 0.0,
      "upper": null
    },
    "timing": {
      "reference": "baseline",
      "repeatable": false,
      "window_unit": null
    },
    "unit": "mg/g",
    "value_type": "continuous"
  }
]
```

</details>

<details><summary>Clinical clock: exact native definition</summary>

```json
{
  "calendar_origin": "2024-01-01",
  "contact_source": {
    "availability_delay": 0.25,
    "delay_shape": 2.0,
    "documentation_delay": 0.25,
    "early_windows": [
      0.0,
      11.25,
      18.75,
      30.0,
      0.0
    ],
    "late_windows": [
      0.0,
      11.25,
      18.75,
      30.0,
      0.0
    ],
    "nominal_times": [
      0.0,
      45.0,
      120.0,
      240.0,
      365.0
    ],
    "observation_delay": 0.0,
    "source_type": "windowed"
  },
  "entry_time_column": null,
  "epochs": [
    {
      "end": 365.0,
      "name": "TREATMENT",
      "start": 0.0
    }
  ],
  "horizon": 365.0,
  "interval_convention": "left_closed_right_open",
  "origin": "randomisation",
  "tie_policy": "stable_stage_precedence",
  "unit": "day"
}
```

</details>

<details><summary>Assignment: exact native definition</summary>

```json
{
  "arms": [
    {
      "arm_id": "control",
      "probability": 0.5
    },
    {
      "arm_id": "active",
      "probability": 0.5
    }
  ],
  "block_size": 4,
  "cluster_membership_column": null,
  "cluster_size": null,
  "cluster_size_coefficient_of_variation": 0.0,
  "design": "parallel_group",
  "independent_unit": "participant",
  "intervention_arm": null,
  "intracluster_correlation": null,
  "intracluster_correlation_scale": null,
  "randomization_method": "permuted_block",
  "stepped_wedge_control_arm": null,
  "stepped_wedge_entry_time_column": null,
  "stepped_wedge_exposure": "time_varying",
  "stepped_wedge_intervention_arm": null,
  "stepped_wedge_switch_times": [],
  "stepped_wedge_transition_duration": 0.0,
  "stratification_variables": []
}
```

</details>

<details><summary>Exposure: exact native definition</summary>

```json
{
  "control_arm": "control",
  "initial_adherence": [
    {
      "arm_id": "control",
      "probability": 1.0
    },
    {
      "arm_id": "active",
      "probability": 1.0
    }
  ],
  "planned_end_time": null
}
```

</details>

<details><summary>Intercurrent events: exact native definition</summary>

```json
[]
```

</details>

<details><summary>Safety events: exact native definition</summary>

```json
[
  {
    "arm_coefficients": [
      {
        "arm_id": "control",
        "value": 0.0
      },
      {
        "arm_id": "active",
        "value": 0.2
      }
    ],
    "ascertainment": "spontaneous",
    "availability_delay": 0.5,
    "baseline_coefficient": 0.25,
    "baseline_variable": "bmi_curve",
    "category": "metabolism and nutrition disorders",
    "cluster_probability_concentration": null,
    "cluster_reference_probability": null,
    "coding_system": "protocol AESI dictionary",
    "dictionary_term": "Hyperkalaemia requiring treatment",
    "documentation_delay": 0.5,
    "effects": [],
    "event_id": "hyperkalaemia",
    "event_type": "safety",
    "exposure_action": "no_change",
    "exposure_action_severities": [],
    "hierarchical_effect_correlations": [],
    "intercept": -4.57972153357891,
    "kind": "safety_event",
    "learned_effect": null,
    "medical_code": "AESI:hyperkalaemia",
    "observation_delay_mean": 2.0,
    "occurrence_timing": "within_contact_interval",
    "outcome_shift": 0.0,
    "recording_delay_shape": 2.0,
    "recurrent": false,
    "reporting_probability": 0.95,
    "resolution_probability_per_contact": 0.5,
    "risk_reference_duration": null,
    "risk_window_end": 365.0,
    "risk_window_start": 0.0,
    "serious_observation_delay_multiplier": 0.25,
    "severity_levels": [
      {
        "level": "mild_or_moderate",
        "probability": 0.7,
        "serious": false,
        "seriousness_criteria": []
      },
      {
        "level": "serious",
        "probability": 0.3,
        "serious": true,
        "seriousness_criteria": [
          "AESHOSP"
        ]
      }
    ],
    "state_coefficients": [],
    "target_arm": null,
    "time_coefficient": 0.0
  }
]
```

</details>

<details><summary>Attendance: exact native definition</summary>

```json
{
  "process_type": "complete"
}
```

</details>

<details><summary>Observation: exact native definition</summary>

```json
{
  "baseline_coefficient": 0.0,
  "effects": [
    {
      "coefficient": -0.01,
      "effect_id": "recorded_observation_prognosis",
      "effect_type": "main",
      "input_variable": "bmi",
      "unit": "log_odds"
    }
  ],
  "event_coefficients": [],
  "hierarchical_effect_correlations": [],
  "initial_observed_outcome": 3.0,
  "intercept": 3.8918202981106265,
  "learned_effect": null,
  "monotone_dropout": false,
  "observe_first_contact": false,
  "process_type": "logistic",
  "state_coefficients": [],
  "terminal_missingness_only": false,
  "terminal_recovery_probability": 0.0,
  "time_coefficient": 0.0
}
```

</details>

<details><summary>Measurement: exact native definition</summary>

```json
{
  "error_model": "exact"
}
```

</details>

<details><summary>Patient state: exact native definition</summary>

```json
null
```

</details>

<details><summary>Patient world: exact native definition</summary>

```json
null
```

</details>

<details><summary>Trial operations: exact native definition</summary>

```json
{
  "budget": 1.0,
  "closeout_days": 0.25,
  "completed_site_size_coefficient_of_variation": null,
  "evidence": {
    "available_at": "2026-09-22",
    "source_id": "TAB-SRC-080",
    "source_role": "scenario_assumption"
  },
  "follow_up_days": 365.0,
  "horizon_days": 915.25,
  "monetary_basis": {
    "currency": "USD",
    "geography": "Synthetic USA/CAN/GBR/DEU",
    "perspective": "trial sponsor",
    "price_year": 2026
  },
  "participant_cost": 0.0,
  "recruitment_mode": "completed_cohort",
  "recruitment_rate_multiplier": 1.0,
  "setup_cost": 0.0,
  "sites": [
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "USA",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_001",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "CAN",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_002",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "GBR",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_003",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "DEU",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_004",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "USA",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_005",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "CAN",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_006",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "GBR",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_007",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "DEU",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_008",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "USA",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_009",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "CAN",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_010",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "GBR",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_011",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "DEU",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_012",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "USA",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_013",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "CAN",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_014",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "GBR",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_015",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "DEU",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_016",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "USA",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_017",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "CAN",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_018",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "GBR",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_019",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "DEU",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_020",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "USA",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_021",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "CAN",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.014797507788161994,
      "site_id": "site_022",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "GBR",
      "maximum_participants": 32,
      "opening_day": 0.0,
      "participants_per_day": 0.029595015576323987,
      "site_id": "site_023",
      "startup_cost": 0.0
    },
    {
      "active_cost_per_day": 0.0,
      "closing_day": 550.0,
      "country_code": "DEU",
      "maximum_participants": 32,
      "opening_day": 30.0,
      "participants_per_day": 0.04439252336448598,
      "site_id": "site_024",
      "startup_cost": 0.0
    }
  ],
  "startup_days": 0.0,
  "target_participants": 380
}
```

</details>

<details><summary>Event-time covariates: exact native definition</summary>

```json
[]
```

</details>

<details><summary>Auxiliary longitudinal estimands: exact native definition</summary>

```json
[
  {
    "analysis_population": "intention_to_treat",
    "control_arm": "control",
    "endpoint_time": 365.0,
    "estimand_id": "generated_endpoint_support",
    "identification_assumptions": [
      "conditional_observation_exchangeability",
      "observation_positivity"
    ],
    "identification_method": "observed_data_derivation",
    "identification_status": "identified_under_assumptions",
    "intercurrent_event_strategies": [],
    "outcome_id": "urine_albumin_creatinine_ratio",
    "protocol_deviation_event_ids": [],
    "sensitivity_parameters": [],
    "supported_analysis_methods": [],
    "treatment_arm": "active"
  }
]
```

</details>

<details><summary>Longitudinal outcomes: exact native definition</summary>

```json
{
  "innovation_correlation": [],
  "outcomes": [
    {
      "arm_effects": [
        {
          "arm_id": "control",
          "value": 0.0
        },
        {
          "arm_id": "active",
          "value": 0.0
        }
      ],
      "baseline_coefficient": 0.0,
      "baseline_effect_scale": "natural_unit",
      "baseline_variable": "bmi",
      "effects": [
        {
          "center": 21.0,
          "coefficient": -18.0,
          "effect_id": "recorded_baseline_prognostic_effect",
          "effect_type": "standardized_polynomial",
          "input_variable": "bmi",
          "power": 1,
          "scale": 6.5,
          "unit": "mg/g"
        },
        {
          "center": 64.0,
          "coefficient": 24.0,
          "effect_id": "age_prognostic_effect",
          "effect_type": "standardized_polynomial",
          "input_variable": "age",
          "power": 1,
          "scale": 11.0,
          "unit": "mg/g"
        },
        {
          "center": 138.0,
          "coefficient": 18.0,
          "effect_id": "secondary_prognostic_effect",
          "effect_type": "standardized_polynomial",
          "input_variable": "baseline_risk",
          "power": 1,
          "scale": 12.0,
          "unit": "mg/g"
        },
        {
          "effect_id": "site_outcome_effect",
          "effect_type": "spline",
          "extrapolation": "constant",
          "input_variable": "site_outcome_context",
          "knots": [
            -1.6666666666666667,
            0.0,
            1.6666666666666667
          ],
          "unit": "mg/g",
          "values": [
            -30.0,
            0.0,
            30.0
          ]
        }
      ],
      "hierarchical_effect_correlations": [],
      "intercept": 300.0,
      "learned_effect": null,
      "lower_bound": 0.0,
      "mean_transition": null,
      "outcome_id": "urine_albumin_creatinine_ratio",
      "residual_correlation_duration": 56.0,
      "residual_process": "adjacent_contact_ar1_support_native",
      "residual_standard_deviation": 120.0,
      "rounding_increment": 1.0,
      "time_coefficient": 0.0,
      "unit": "mg/g",
      "upper_bound": null,
      "within_participant_autocorrelation": 0.6
    }
  ],
  "primary_outcome_id": "urine_albumin_creatinine_ratio"
}
```

</details>

<details><summary>Survival outcomes: exact native definition</summary>

```json
null
```

</details>

<details><summary>Binary outcomes: exact native definition</summary>

```json
[]
```

</details>

<details><summary>Count outcomes: exact native definition</summary>

```json
[]
```

</details>

<details><summary>Endpoint validation: exact native definition</summary>

```json
null
```

</details>
