# Cascade kidney-disease monitoring trial: primary analysis of urine albumin-to-creatinine ratio through Day 365

**Ariadne Clinical Research Collaborative**

| Document | Statistical analysis request |
| --- | --- |
| Document ID | ACRC-AREQ-A1DFB2BF |
| Owner | Study Biostatistics |
| Status | Approved |
| Effective milestone | Issued at the stated evidence cutoff |
| Purpose | State the decision question, available evidence, requested analyses, and deliverables. |
| Related document classes | Protocol summary, Statistical reporting standard |

## Clinical question

What is the kidney-protection-therapy minus usual-care mean difference in albuminuria at Day 365 when all recorded follow-up measurements are analysed?

Comparison population: all randomized participants. 

Report the treatment comparison in mg/g, with a 95% confidence interval and a statistical report.

## Study design

Individually randomized concurrent parallel-group clinical trial in albuminuria reduction in chronic kidney disease.

## Study files

- `protocol.md`: Protocol definitions for population, treatment, endpoint, follow-up, and analysis timing
- `data_dictionary.csv`: Variable names, types, units, roles, timing, derivations, and analysis notes
- `statistical_analysis_plan.md`: Prespecified estimand, analysis population, method, diagnostics, and sensitivity analyses
- `data/analysis.parquet`: Analysis-ready participant records with treatment, endpoint, follow-up, and declared covariates
- `data/raw/standards.zip`: SDTM/ADaM views of the same observed evidence, with source-variable dictionary.
