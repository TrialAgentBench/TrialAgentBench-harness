# Statistical analysis plan

**Ariadne Clinical Research Collaborative**

| Document | Statistical analysis plan |
| --- | --- |
| Document ID | ACRC-SAP-CE0ADE30 |
| Study ID | trial_cf8ac2ced2149a5df481 |
| Version | 1.0 |
| Owner | Biostatistics |
| Status | Approved |
| Effective milestone | Finalized before database lock and unblinding |
| Purpose | Prespecify the estimand, primary analysis, uncertainty procedure, diagnostics, and reporting. |
| Related document classes | Protocol summary, Analysis data specification, Statistical analysis request |

Primary objective: What is the kidney-protection-therapy minus usual-care mean difference in albuminuria at Day 365 when all recorded follow-up measurements are analysed?

The treatment contrast is add-on kidney-protection therapy minus usual kidney-protection care. The independent unit is the randomized participant.

Prespecified primary method: Fit a Gaussian marginal GEE containing an intercept, randomized-arm indicator, continuous `occurrence_time` in days, and their interaction. Use an exchangeable working correlation and participant-clustered sandwich uncertainty. Include no higher-order time term, spline term, or additional covariate. Evaluate the active-minus-control contrast at Day 365. The prespecified uncertainty procedure is participant-clustered sandwich standard error.

Primary estimand attributes (ICH E9(R1)) [`marginal_urine_albumin_creatinine_ratio_mean_difference`]: Population: all randomized participants. Treatment conditions: add-on kidney-protection therapy versus usual kidney-protection care, according to randomized assignment. Variable: urine albumin-to-creatinine ratio through Day 365; assessment horizon Day 365. Intercurrent events and strategies: No additional event-specific strategy is declared. Treatment changes do not themselves remove participants from the target population. Study withdrawal ends observation; subsequent endpoints are missing, not zero or inferred. Population-level summary measure: mean difference (active minus control).

Missing-data handling: retain all randomized participants in cohort accounting and analyze by assigned treatment in the declared estimand population. Source endpoint tables contain actual assessments; left-join them to the participant roster to identify absent assessments. Missing values are never recoded as no event, zero count or successful recovery. Summarize missingness by arm, baseline covariates, prior recorded outcomes and recorded withdrawal.

The primary method uses available measurements under its stated mean/observation assumptions; available-case inference requires non-informative observation for the fitted marginal model. For sensitivity, use multiple imputation under missing at random conditional on assigned arm, recorded baseline variables and prior observed outcomes (50 imputations); refit the complete analysis in each and combine estimates/variances using Rubin's rules. Then shift imputed endpoint values separately by arm over -1, -0.5, 0, 0.5 and 1 observed residual standard deviation, respecting the documented scale support. Report estimates, intervals and any decision tipping points; these shifts are sensitivity assumptions, not supplied observations.

Describe the analysis used and any supported alternative in the report.

Prespecified diagnostic: Tabulate observed endpoint records by randomized arm and follow-up stratum. Use exact recorded times when there are at most 12; otherwise use four equal-width intervals over the declared follow-up. Report maximum_arm_observation_fraction_difference, minimum_observation_fraction, overall_observation_fraction, and time_stratum_count with the declared units. Interpret these as descriptive measures without a universal pass/fail cutoff. Report the result on the visit specific observation fraction scale. Report observed and missing counts by randomized arm and scheduled or recorded time; no universal categorical severity cutoff

Prespecified diagnostic: Fit the declared repeated-measures mean model to complete endpoint records and standardize residuals by their root-mean-square scale. Use exact recorded times when there are at most 12; otherwise use four equal-width intervals over follow-up. Report maximum_absolute_cell_standardized_residual_mean by arm and time, absolute_residual_fitted_value_correlation, absolute_residual_time_correlation, standardized_residual_standard_deviation, and complete_record_count. Interpret these as descriptive measures without a universal pass/fail cutoff. Report the result on the standardized residual pattern scale. Report residual location and spread across fitted values, randomized arms, and follow-up time; no universal categorical severity cutoff

Use an analysis supported by the randomized design and observed follow-up. Assess assumptions that could change the estimate or its uncertainty, and use a supported alternative or sensitivity analysis when the prespecified analysis is not adequate. Report the treatment-effect estimate and a 95% confidence interval. Explain any sensitivity analyses separately and the uncertainty they address. Report diagnostics and the practical interpretation.
