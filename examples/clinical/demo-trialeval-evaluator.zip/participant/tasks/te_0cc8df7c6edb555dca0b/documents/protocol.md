# Protocol summary

**Ariadne Clinical Research Collaborative**

| Document | Protocol summary |
| --- | --- |
| Document ID | ACRC-PROT-CE0ADE30 |
| Study ID | trial_cf8ac2ced2149a5df481 |
| Version | 1.0 |
| Owner | Clinical Science |
| Status | Approved |
| Effective milestone | Approved before participant enrolment |
| Purpose | Define the clinical question, study design, population, interventions, endpoints, and follow-up. |
| Related document classes | Statistical analysis plan, Source-data quality plan |

Study: Cascade kidney-disease monitoring trial.

Therapeutic area: nephrology.

Clinical setting: albuminuria reduction in chronic kidney disease.

Population: adults with chronic kidney disease and persistent albuminuria.

Study design: parallel group.

Target population: all randomized participants.

Treatment groups: add-on kidney-protection therapy versus usual kidney-protection care.

Primary endpoint: urine albumin-to-creatinine ratio through Day 365 by the protocol horizon.

Endpoint definition: Central-laboratory urine albumin-to-creatinine ratio recorded during protocol follow-up; the primary contrast is evaluated at Day 365. The time-zero urine sample is the baseline measurement; follow-up trajectories are conditioned on that same recorded sample.

Safety endpoint: Hyperkalaemia requiring treatment.

Safety endpoint definition: Supplied classification of hyperkalaemia requiring treatment through Day 365. The protocol serious-event category comprises episodes requiring inpatient admission or prolongation of an existing admission. Seriousness is recorded separately from intensity grade. This is a classified safety episode; laboratory/physiological thresholds and a distinct clinical intensity grade are not separately modelled. The severity field combines mild-or-moderate and serious categories; seriousness criteria are recorded separately.

Primary estimand attributes (ICH E9(R1)) [`marginal_urine_albumin_creatinine_ratio_mean_difference`]: Population: all randomized participants. Treatment conditions: add-on kidney-protection therapy versus usual kidney-protection care, according to randomized assignment. Variable: urine albumin-to-creatinine ratio through Day 365; assessment horizon Day 365. Intercurrent events and strategies: No additional event-specific strategy is declared. Treatment changes do not themselves remove participants from the target population. Study withdrawal ends observation; subsequent endpoints are missing, not zero or inferred. Population-level summary measure: mean difference (active minus control).

Planned sample size: 128 participants. The information minimum is 128; allocation rounding uses multiples of 4. Allocation ratio is 1:1 (treatment allocation 0.5); realized arm counts may differ under randomization. Dropout allowance: no separate percentage inflation is added. Any retention adjustment is already included in the event-yield assumptions below. A registry-sized scenario uses its declared planning alternative; planning power is not achieved power or a guarantee at the realized treatment effect.

Sizing reference: registry median; target 125 participants. The matched registry cohort has 93 trials and median enrolment 125. The selected information plan and allocation rounding above govern this study.

Planning assumptions: power = 0.9; two sided alpha = 0.05; treatment allocation = 0.5; design type = continuous; treatment difference = -78.40053; outcome standard deviation = 134.66407864998737; outcome unit = mg/g. Minimum cohort from the prespecified normal_mean_difference design with 90.0% power and two-sided 5% alpha, planned for an assumed effect 1.74 times the reference alternative. The final-endpoint variance uses the declared residual variance and a Cauchy–Schwarz bound on baseline and state contributions, with measurement rounding included. Planning assumptions: normal mean approximation. Achieved information requires separate assessment of operating characteristics.

Eligibility criteria: adults with chronic kidney disease and persistent albuminuria; age 30–88 years. Disease setting, stage and prior therapy are represented by the cohort description above; recorded baseline measurements describe the cohort, rather than adding unrecorded screening filters. Exclusion criteria: no further clinical exclusions, pregnancy exclusions or laboratory screening rules are separately modelled; do not infer them from a conventional real-world protocol.

Regimen: add-on kidney-protection therapy versus usual kidney-protection care. These are study-specific treatment conditions, with no marketed product identity. Dose, route and dosing frequency are not separately modelled or supplied. Exposure records document received treatment at contacts, not dispensing or dose administration. Background care is represented by the comparator; no additional rescue-medication dosing history is supplied.

Schedule of assessments: nominal contact days 0, 45, 120, 240, 365. Permitted contact windows (days since entry): 0–0, 33.75–56.25, 101.25–138.75, 210–270, 365–365. Actual contacts retain their recorded times. Baseline covariates are measured at entry; endpoint and treatment receipt are assessed at the recorded contacts. Event occurrence, later confirmation and report availability use separate clocks. Visit nonattendance or withdrawal can leave no source assessment.

The final database cutoff follows planned closeout and receipt of all available reports. Waiting for reports does not recover missing measurements.

Planned operations closeout: study day 915.25.

Follow-up: 365 days.

Study opening date: 2024-01-01.

Protocol epochs: TREATMENT, days 0–365.

Follow-up and endpoint ascertainment: The extract retains the randomized cohort, recorded endpoint assessments and follow-up records. Occurrence, assessment and reporting times have distinct meanings. Participants without a recorded endpoint remain in the cohort; absence of a record does not itself establish absence of an event.

Treatment discontinuation: assigned active study therapy stops and usual kidney-protection care continues. Outcome follow-up continues after the treatment change under the protocol estimand.

Treatment switch: received treatment follows the recorded treatment history. Outcome follow-up continues after the treatment change under the protocol estimand.

Treatment assignment is analyzed according to the declared estimand. Treatment-use events, follow-up termination, missing observations, and safety outcomes retain separate meanings.
