# Cascade kidney-disease monitoring trial: primary analysis of urine albumin-to-creatinine ratio through Day 365

**Ariadne Clinical Research Collaborative**

| Document | Statistical analysis request |
| --- | --- |
| Document ID | ACRC-AREQ-9C18B547 |
| Owner | Study Biostatistics |
| Status | Approved |
| Effective milestone | Issued at the stated evidence cutoff |
| Purpose | State the decision question, available evidence, requested analyses, and deliverables. |
| Related document classes | Protocol summary, Statistical reporting standard |

## Clinical question

What is the kidney-protection-therapy minus usual-care mean difference in albuminuria at Day 365 when all recorded follow-up measurements are analysed?

Comparison population: all randomized participants. 

Report the treatment comparison with a 95% confidence interval, and a statistical report.

| Result identifier | Treatment comparison | Unit |
| --- | --- | --- |
| `marginal_urine_albumin_creatinine_ratio_mean_difference` | mean difference | mg/g |
| `prespecified_primary_analysis` | mean difference | mg/g |

Under `prespecified_primary_analysis`, report the prespecified primary analysis executed exactly as the statistical analysis plan specifies, even where you judge the plan inadequate. Under `marginal_urine_albumin_creatinine_ratio_mean_difference`, report the analysis you would act on; it drives the trial decision. The plan as executed and `marginal_urine_albumin_creatinine_ratio_mean_difference` coincide when the plan is adequate. The plan as executed is scored separately, for agreement with the plan, and does not enter the score or the decision of the analysis you act on.

## Treatment-effect prior

True treatment effects in this collection of studies are drawn from a disclosed prior. The primary comparison's true effect, divided by its sampling standard deviation at the planned sample size (its signal-to-noise ratio, positive when the active treatment is better), follows the mixture of zero-mean normal distributions with weights 0.32, 0.31, 0.3, 0.07 and standard deviations 0.61, 1.42, 2.16, 5.64 (van Zwet E, Schwab S, Senn S. The statistical properties of RCTs and a proposal for shrinkage. Stat Med. 2021;40(27):6107-6117. doi:10.1002/sim.9173). The same multiple of the planned effect applies to every outcome of the study. For this study the ratio is truncated to [-7.47, 1.69].

Your estimate and interval drive a development decision: whether to run a confirmatory trial, and how large. That decision already combines your result with this prior, so report the estimate and interval that this trial's data support; shrinking them toward the prior counts the prior twice.

## Study design

Individually randomized concurrent parallel-group clinical trial in albuminuria reduction in chronic kidney disease.

## Study files

- `protocol.md`: Protocol definitions for population, treatment, endpoint, follow-up, and analysis timing
- `data_dictionary.csv`: Variable names, types, units, roles, timing, derivations, and analysis notes
- `statistical_analysis_plan.md`: Prespecified estimand, analysis population, method, diagnostics, and sensitivity analyses
- `data/analysis.parquet`: Analysis-ready participant records with treatment, endpoint, follow-up, and declared covariates
- `data/raw/standards.zip`: SDTM/ADaM views of the same observed evidence, with source-variable dictionary.
