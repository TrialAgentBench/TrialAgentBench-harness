# Setup review: tdw-ed4fcb8dc68f

MERIDIAN rheumatoid-arthritis programme: add-on treatment for rheumatoid arthritis despite conventional therapy

This page reveals evaluator-only simulation assumptions. Read the participant evidence protocol and task request alongside it. The definitions below describe the clinical world; the task's committee_brief.md and authored_programme.json define the actual design space, budget, calendar horizon and sponsor preferences. They are the authority for execution.

The initial cohort supports standardized observed candidate-control associations. These numerical targets describe recorded evidence and do not assert that observational adjustment identifies a causal treatment effect. Measured clinical fields are released; latent factors and counterfactual outcomes remain private.

Prospective evidence comes from a frozen patient population with shared treatment and dose counterfactuals. The agent authors safety, exploration and confirmation studies, including allocation, recruitment, schedules and permitted interim looks. The runtime samples this pool reproducibly and reveals only accrued observations; it performs no native generation during the task. Raw domains and analysis-ready tables represent the same evidence.

Study analyses target the declared population and endpoint window. Terminal development value uses complete-population, final-horizon benefit and safety contrasts in pool/manifest.json, combined with public sponsor preferences and incurred costs and calendar time. An acquired study sample does not replace that terminal target. Stopping is a legitimate decision.

Both analysis streams return estimates and 95% intervals through the common numerical interface. Grading compares those numbers with the declared targets; it does not adjudicate a preferred method or require diagnostic flags. Observational reference precision and source provenance are retained in observational_association_reference.json. Frozen pool records allow separate reconstruction of finite-population prospective contrasts.

These are declared simulation assumptions, not empirical calibration unless the clinical provenance explicitly supplies it. This generated page is not clinical sign-off or evidence that release qualification has passed.

<details><summary>Clinical interpretation and measurement: exact native definition</summary>

```json
{
  "baseline_assignment": [
    {
      "log_odds_ratio_per_sd": 0.65,
      "variable_id": "baseline_risk"
    },
    {
      "log_odds_ratio_per_sd": -0.2,
      "variable_id": "age_at_index"
    },
    {
      "log_odds_ratio_per_sd": 0.45,
      "variable_id": "secondary_risk"
    },
    {
      "log_odds_ratio_per_sd": 0.05,
      "variable_id": "sex_code"
    },
    {
      "log_odds_ratio_per_sd": 0.05,
      "variable_id": "body_mass_index"
    },
    {
      "log_odds_ratio_per_sd": 0.15,
      "variable_id": "c_reactive_protein"
    },
    {
      "log_odds_ratio_per_sd": 0.05,
      "variable_id": "current_smoker"
    },
    {
      "log_odds_ratio_per_sd": 0.0,
      "variable_id": "diagnosis_duration_months_fraction"
    },
    {
      "log_odds_ratio_per_sd": 0.15,
      "variable_id": "diagnosis_duration_months"
    }
  ],
  "baseline_factors": [
    {
      "derivation": null,
      "distribution": {
        "family": "normal",
        "lower": 2.0,
        "mean": 5.2,
        "standard_deviation": 1.0,
        "upper": 9.0
      },
      "outcome_difference_per_sd": 0.8,
      "role": "measured",
      "safety_log_odds_per_sd": 0.0,
      "unit": "DAS28 points",
      "variable_id": "baseline_risk"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "normal",
        "lower": 18.0,
        "mean": 55.0,
        "standard_deviation": 12.0,
        "upper": 85.0
      },
      "outcome_difference_per_sd": 0.1,
      "role": "measured",
      "safety_log_odds_per_sd": 0.35,
      "unit": "years",
      "variable_id": "age_at_index"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "bernoulli",
        "lower": null,
        "mean": 0.35,
        "standard_deviation": 0.47696960070847283,
        "upper": null
      },
      "outcome_difference_per_sd": 0.25,
      "role": "measured",
      "safety_log_odds_per_sd": 0.3,
      "unit": "indicator",
      "variable_id": "secondary_risk"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "bernoulli",
        "lower": null,
        "mean": 0.8,
        "standard_deviation": 0.39999999999999997,
        "upper": null
      },
      "outcome_difference_per_sd": 0.08,
      "role": "measured",
      "safety_log_odds_per_sd": 0.03,
      "unit": "indicator",
      "variable_id": "sex_code"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "normal",
        "lower": 16.0,
        "mean": 28.0,
        "standard_deviation": 5.0,
        "upper": 50.0
      },
      "outcome_difference_per_sd": 0.08,
      "role": "measured",
      "safety_log_odds_per_sd": 0.1,
      "unit": "kg/m2",
      "variable_id": "body_mass_index"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "log_normal",
        "lower": null,
        "mean": 12.0,
        "standard_deviation": 15.0,
        "upper": null
      },
      "outcome_difference_per_sd": 0.15,
      "role": "measured",
      "safety_log_odds_per_sd": 0.1,
      "unit": "mg/L",
      "variable_id": "c_reactive_protein"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "bernoulli",
        "lower": null,
        "mean": 0.2,
        "standard_deviation": 0.4,
        "upper": null
      },
      "outcome_difference_per_sd": 0.08,
      "role": "measured",
      "safety_log_odds_per_sd": 0.15,
      "unit": "0=no, 1=yes",
      "variable_id": "current_smoker"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "beta",
        "lower": null,
        "mean": 0.20516129032258063,
        "standard_deviation": 0.18686362286581598,
        "upper": null
      },
      "outcome_difference_per_sd": 0.0,
      "role": "latent",
      "safety_log_odds_per_sd": 0.0,
      "unit": "fraction",
      "variable_id": "diagnosis_duration_months_fraction"
    },
    {
      "derivation": {
        "effects": [
          {
            "coefficient": -195.0,
            "effect_id": "minimum_diagnosis_age",
            "effect_type": "main",
            "input_variable": "diagnosis_duration_months_fraction",
            "unit": "months"
          },
          {
            "coefficient": 12.0,
            "effect_id": "eligible_lifetime",
            "effect_type": "interaction",
            "input_variables": [
              "age_at_index",
              "diagnosis_duration_months_fraction"
            ],
            "unit": "months"
          }
        ],
        "hierarchical_effect_correlations": [],
        "inputs": [
          "diagnosis_duration_months_fraction",
          "age_at_index"
        ],
        "learned": null,
        "measurement_model": null,
        "mechanism_id": "diagnosis_duration_months",
        "mechanism_type": "derived_effect",
        "nominal_calibration": null,
        "nominal_logits": null,
        "observation_rule": null,
        "output": "diagnosis_duration_months",
        "output_levels": null,
        "output_unit": "months",
        "parameters": [
          {
            "input_variable": null,
            "parameter_id": "intercept",
            "role": "intercept",
            "source": "fixed",
            "unit": "months",
            "value": 3.0
          }
        ],
        "probability_bounds": null,
        "residual_scale": null,
        "stochastic": false
      },
      "distribution": {
        "family": "normal",
        "lower": null,
        "mean": 98.39999999999999,
        "standard_deviation": 95.64,
        "upper": null
      },
      "outcome_difference_per_sd": 0.165,
      "role": "measured",
      "safety_log_odds_per_sd": 0.1,
      "unit": "months",
      "variable_id": "diagnosis_duration_months"
    }
  ],
  "baseline_fields": [
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "disease_measure",
      "field_id": "baseline_das28_score",
      "label": "Baseline Disease Activity Score in 28 joints",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 0.01
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "baseline_risk",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": 10.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "DAS28 points",
      "value_type": "continuous"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "demographic",
      "field_id": "age_years",
      "label": "Age at treatment initiation",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "age_at_index",
      "source_ids": [],
      "support": {
        "lower": 18.0,
        "upper": 95.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "years",
      "value_type": "integer"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "treatment",
      "field_id": "prior_biologic_dmard_use",
      "label": "Prior biologic DMARD use before baseline",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "secondary_risk",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": 1.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "0=no, 1=yes",
      "value_type": "integer"
    },
    {
      "allowed_values": null,
      "categories": [
        "male",
        "female"
      ],
      "evidence_role": "mechanism_relative",
      "family": "demographic",
      "field_id": "sex",
      "label": "Recorded sex",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Recorded baseline sex",
        "missing_value": "",
        "resolution": null
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [
        0.0,
        1.0
      ],
      "source_direction": 1,
      "source_field_id": "sex_code",
      "source_ids": [],
      "support": null,
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "category",
      "value_type": "categorical"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "anthropometric",
      "field_id": "baseline_body_mass_index",
      "label": "Body mass index",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 0.1
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "body_mass_index",
      "source_ids": [],
      "support": {
        "lower": 16.0,
        "upper": 50.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "kg/m2",
      "value_type": "continuous"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "laboratory",
      "field_id": "baseline_c_reactive_protein",
      "label": "C-reactive protein",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 0.1
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "c_reactive_protein",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": null
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "mg/L",
      "value_type": "continuous"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "demographic",
      "field_id": "baseline_current_smoker",
      "label": "Current cigarette smoking",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "current_smoker",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": 1.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "0=no, 1=yes",
      "value_type": "integer"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "disease_measure",
      "field_id": "baseline_diagnosis_duration_months",
      "label": "Time since diagnosis",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "diagnosis_duration_months",
      "source_ids": [],
      "support": {
        "lower": 3.0,
        "upper": null
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "months",
      "value_type": "integer"
    }
  ],
  "candidate_class": "oral immunomodulatory candidates",
  "candidate_code_prefix": "MRD",
  "candidate_descriptor": "oral immunomodulatory candidate",
  "candidate_labels": [
    "MRD-88811",
    "MRD-93853",
    "MRD-81623"
  ],
  "clinical_setting": "add-on treatment for rheumatoid arthritis despite conventional therapy",
  "comparator_label": "standard care",
  "confirmatory_assessment_days": 168,
  "count_dispersion": null,
  "endpoint_support_lower": 0.0,
  "endpoint_support_upper": 10.0,
  "exploratory_assessment_days": 84,
  "maximum_acceptable_safety_risk_difference": 0.03,
  "observational_assessment_days": 168,
  "outcome_field_id": "das28_score_end_of_follow_up",
  "outcome_label": "Disease Activity Score in 28 joints at the endpoint assessment",
  "outcome_link_scale": 1.1,
  "outcome_object": "Rheumatoid arthritis",
  "outcome_offset": 1.0,
  "outcome_reference_difference": 0.6,
  "outcome_reference_interpretation": "A 0.6-point within-person improvement is the lower EULAR moderate-response threshold; it is an interpretation anchor, not a required between-group effect.",
  "outcome_rounding_increment": 0.01,
  "outcome_scale": 1.1,
  "outcome_unit": "DAS28 points",
  "population": "adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy",
  "profile_id": "rheumatoid_arthritis",
  "programme_name": "MERIDIAN rheumatoid-arthritis programme",
  "recruitment_countries": [
    "USA",
    "CAN",
    "GBR",
    "DEU"
  ],
  "recruitment_subsets": [
    {
      "criteria": [
        {
          "column": "prior_biologic_dmard_use",
          "operator": "greater_than",
          "value": 0.0
        }
      ],
      "label": "Prior biologic DMARD use",
      "subset_id": "prior_biologic"
    },
    {
      "criteria": [
        {
          "column": "baseline_c_reactive_protein",
          "operator": "greater_than_or_equal",
          "value": 10.0
        },
        {
          "column": "baseline_diagnosis_duration_months",
          "operator": "greater_than_or_equal",
          "value": 60.0
        }
      ],
      "label": "CRP at least 10 mg/L and diagnosis for at least five years",
      "subset_id": "inflammation_longstanding"
    }
  ],
  "regimens": [
    {
      "amount_mg": 15.0,
      "dose": "standard",
      "interval_days": 1,
      "route": "oral"
    },
    {
      "amount_mg": 30.0,
      "dose": "intensified",
      "interval_days": 1,
      "route": "oral"
    }
  ],
  "registry_family_id": "TD-RA",
  "rescue_event": {
    "arm_coefficients": [
      {
        "arm_id": "control",
        "value": 0.0
      },
      {
        "arm_id": "active",
        "value": 0.0
      }
    ],
    "baseline_coefficient": 0.3,
    "baseline_variable": "baseline_risk",
    "cluster_probability_concentration": null,
    "cluster_reference_probability": null,
    "effects": [],
    "event_id": "rescue_antirheumatic_therapy",
    "event_type": "intercurrent",
    "exposure_action": "no_change",
    "hierarchical_effect_correlations": [],
    "intercept": -3.0,
    "kind": "rescue_medication",
    "learned_effect": null,
    "occurrence_timing": "within_contact_interval",
    "outcome_shift": -0.25,
    "recurrent": false,
    "risk_reference_duration": 70.0,
    "risk_window_end": null,
    "risk_window_start": 98.0,
    "state_coefficients": [],
    "target_arm": null,
    "time_coefficient": 0.0,
    "withdrawal_reason": null,
    "withdrawal_reason_text": null
  },
  "residual_confounding_context": "Routine-care baseline records include DAS28, age and prior biologic DMARD use; treatment was not randomized.",
  "risk_factor_correlation_matrix": [
    [
      1.0,
      0.1,
      0.3,
      0.08,
      0.15,
      0.25,
      0.1,
      0.0,
      0.25
    ],
    [
      0.1,
      1.0,
      0.2,
      0.008,
      0.015,
      0.025,
      0.01,
      0.0,
      0.1
    ],
    [
      0.3,
      0.2,
      1.0,
      0.024,
      0.045,
      0.075,
      0.03,
      0.0,
      0.15
    ],
    [
      0.08,
      0.008,
      0.024,
      1.0,
      0.012,
      0.02,
      0.008,
      0.0,
      0.02
    ],
    [
      0.15,
      0.015,
      0.045,
      0.012,
      1.0,
      0.0375,
      0.015,
      0.0,
      0.0375
    ],
    [
      0.25,
      0.025,
      0.075,
      0.02,
      0.0375,
      1.0,
      0.025,
      0.0,
      0.0625
    ],
    [
      0.1,
      0.01,
      0.03,
      0.008,
      0.015,
      0.025,
      1.0,
      0.0,
      0.025
    ],
    [
      0.0,
      0.0,
      0.0,
      0.0,
      0.0,
      0.0,
      0.0,
      1.0,
      0.0
    ],
    [
      0.25,
      0.1,
      0.15,
      0.02,
      0.0375,
      0.0625,
      0.025,
      0.0,
      1.0
    ]
  ],
  "risk_factor_dependence_scale": "latent",
  "safety_event_id": "infection_aesi",
  "safety_events": [
    {
      "category": "infection",
      "coding_system": "Protocol AESI dictionary v1",
      "dictionary_term": "Upper respiratory tract infection",
      "discontinuation_severities": [
        "severe"
      ],
      "event_id": "respiratory_infection",
      "hazard_share": 0.65,
      "medical_code": "Upper respiratory tract infection",
      "resolution_probability_per_contact": 0.8,
      "severity_levels": [
        {
          "level": "mild_or_moderate",
          "probability": 0.98,
          "serious": false,
          "seriousness_criteria": []
        },
        {
          "level": "severe",
          "probability": 0.02,
          "serious": true,
          "seriousness_criteria": [
            "AESHOSP"
          ]
        }
      ]
    },
    {
      "category": "infection",
      "coding_system": "Protocol AESI dictionary v1",
      "dictionary_term": "Urinary tract infection",
      "discontinuation_severities": [
        "severe"
      ],
      "event_id": "urinary_infection",
      "hazard_share": 0.35,
      "medical_code": "Urinary tract infection",
      "resolution_probability_per_contact": 0.6,
      "severity_levels": [
        {
          "level": "mild_or_moderate",
          "probability": 0.95,
          "serious": false,
          "seriousness_criteria": []
        },
        {
          "level": "severe",
          "probability": 0.05,
          "serious": true,
          "seriousness_criteria": [
            "AESHOSP"
          ]
        }
      ]
    }
  ],
  "safety_field_id": "infection_aesi_end_of_follow_up",
  "safety_label": "treatment-emergent infection of special interest by the endpoint assessment",
  "screen_failure_fraction": 0.4,
  "screening_candidates_per_site_month": 13.33,
  "site_activation_days": 120,
  "site_case_mix_latent_icc": 0.05,
  "site_outcome_standard_deviation": 0.264,
  "site_safety_log_odds_standard_deviation": 0.25,
  "source_ids": [
    "TAB-SRC-068",
    "TAB-SRC-094"
  ],
  "study_options": [
    {
      "cluster_size": null,
      "cost": 7.5,
      "design": "parallel_group",
      "dose": "standard",
      "duration_days": 126,
      "endpoint_assessment_days": 84,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 300,
      "phase": "exploratory",
      "population": "all_eligible",
      "study_id": "ra_exploratory_all_eligible"
    },
    {
      "cluster_size": null,
      "cost": 9.0,
      "design": "parallel_group",
      "dose": "intensified",
      "duration_days": 126,
      "endpoint_assessment_days": 84,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 160,
      "phase": "exploratory",
      "population": "higher_baseline_risk",
      "study_id": "ra_exploratory_higher_risk"
    },
    {
      "cluster_size": null,
      "cost": 20.0,
      "design": "parallel_group",
      "dose": "standard",
      "duration_days": 224,
      "endpoint_assessment_days": 168,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 1000,
      "phase": "confirmatory",
      "population": "all_eligible",
      "study_id": "ra_confirmatory_all_eligible"
    },
    {
      "cluster_size": null,
      "cost": 24.5,
      "design": "parallel_group",
      "dose": "standard",
      "duration_days": 224,
      "endpoint_assessment_days": 168,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 640,
      "phase": "confirmatory",
      "population": "higher_baseline_risk",
      "study_id": "ra_confirmatory_higher_risk"
    }
  ],
  "therapeutic_area": "rheumatology",
  "treatment_discontinuation_risk": 0.08,
  "typical_outcome_effect": -1.0
}
```

</details>

<details><summary>Observational world and information: exact native definition</summary>

```json
{
  "cohort": {
    "baseline_context_features": [
      {
        "encoding": "label",
        "quantity": {
          "levels": [
            "USA",
            "CAN",
            "GBR",
            "DEU"
          ],
          "probabilities": [
            0.23668639053254434,
            0.21893491124260353,
            0.2544378698224852,
            0.28994082840236685
          ],
          "quantity_type": "categorical_distribution"
        },
        "role": "baseline",
        "variable_id": "country_code"
      },
      {
        "encoding": "label",
        "quantity": {
          "distributions": [
            {
              "levels": [
                "site_001",
                "site_005",
                "site_009",
                "site_013",
                "site_017",
                "site_021",
                "site_025",
                "site_029",
                "site_033",
                "site_037",
                "site_041",
                "site_045",
                "site_049",
                "site_053",
                "site_057",
                "site_061",
                "site_065",
                "site_069",
                "site_073",
                "site_077"
              ],
              "parent_level": "USA",
              "probabilities": [
                0.025,
                0.07500000000000001,
                0.07500000000000001,
                0.025,
                0.025,
                0.025,
                0.07500000000000001,
                0.05,
                0.05,
                0.05,
                0.05,
                0.025,
                0.07500000000000001,
                0.025,
                0.07500000000000001,
                0.025,
                0.07500000000000001,
                0.05,
                0.05,
                0.07500000000000001
              ]
            },
            {
              "levels": [
                "site_002",
                "site_006",
                "site_010",
                "site_014",
                "site_018",
                "site_022",
                "site_026",
                "site_030",
                "site_034",
                "site_038",
                "site_042",
                "site_046",
                "site_050",
                "site_054",
                "site_058",
                "site_062",
                "site_066",
                "site_070",
                "site_074",
                "site_078"
              ],
              "parent_level": "CAN",
              "probabilities": [
                0.08108108108108109,
                0.027027027027027025,
                0.08108108108108109,
                0.027027027027027025,
                0.05405405405405405,
                0.08108108108108109,
                0.05405405405405405,
                0.05405405405405405,
                0.05405405405405405,
                0.05405405405405405,
                0.027027027027027025,
                0.027027027027027025,
                0.05405405405405405,
                0.08108108108108109,
                0.027027027027027025,
                0.027027027027027025,
                0.027027027027027025,
                0.027027027027027025,
                0.05405405405405405,
                0.08108108108108109
              ]
            },
            {
              "levels": [
                "site_003",
                "site_007",
                "site_011",
                "site_015",
                "site_019",
                "site_023",
                "site_027",
                "site_031",
                "site_035",
                "site_039",
                "site_043",
                "site_047",
                "site_051",
                "site_055",
                "site_059",
                "site_063",
                "site_067",
                "site_071",
                "site_075",
                "site_079"
              ],
              "parent_level": "GBR",
              "probabilities": [
                0.046511627906976744,
                0.023255813953488372,
                0.046511627906976744,
                0.023255813953488372,
                0.046511627906976744,
                0.06976744186046512,
                0.046511627906976744,
                0.06976744186046512,
                0.046511627906976744,
                0.06976744186046512,
                0.046511627906976744,
                0.046511627906976744,
                0.046511627906976744,
                0.046511627906976744,
                0.023255813953488372,
                0.06976744186046512,
                0.06976744186046512,
                0.06976744186046512,
                0.06976744186046512,
                0.023255813953488372
              ]
            },
            {
              "levels": [
                "site_004",
                "site_008",
                "site_012",
                "site_016",
                "site_020",
                "site_024",
                "site_028",
                "site_032",
                "site_036",
                "site_040",
                "site_044",
                "site_048",
                "site_052",
                "site_056",
                "site_060",
                "site_064",
                "site_068",
                "site_072",
                "site_076",
                "site_080"
              ],
              "parent_level": "DEU",
              "probabilities": [
                0.061224489795918366,
                0.04081632653061224,
                0.061224489795918366,
                0.04081632653061224,
                0.02040816326530612,
                0.061224489795918366,
                0.061224489795918366,
                0.061224489795918366,
                0.04081632653061224,
                0.02040816326530612,
                0.02040816326530612,
                0.061224489795918366,
                0.061224489795918366,
                0.061224489795918366,
                0.061224489795918366,
                0.02040816326530612,
                0.061224489795918366,
                0.061224489795918366,
                0.061224489795918366,
                0.061224489795918366
              ]
            }
          ],
          "parent_variable": "country_code",
          "quantity_type": "nested_categorical_distribution"
        },
        "role": "baseline",
        "variable_id": "site_id"
      }
    ],
    "baseline_grouping": {
      "dependence_id": "baseline_site_case_mix",
      "dependence_type": "hierarchical_random_intercept",
      "group_root_seed": 288949957302872225,
      "group_variable": "site_id",
      "marginal_dependence": null,
      "random_effect_correlation": [
        [
          1.0,
          0.1,
          0.3,
          0.08,
          0.15,
          0.25,
          0.1,
          0.0,
          0.25
        ],
        [
          0.1,
          1.0,
          0.2,
          0.008,
          0.015,
          0.025,
          0.01,
          0.0,
          0.1
        ],
        [
          0.3,
          0.2,
          1.0,
          0.024,
          0.045,
          0.075,
          0.03,
          0.0,
          0.15
        ],
        [
          0.08,
          0.008,
          0.024,
          1.0,
          0.012,
          0.02,
          0.008,
          0.0,
          0.02
        ],
        [
          0.15,
          0.015,
          0.045,
          0.012,
          1.0,
          0.0375,
          0.015,
          0.0,
          0.0375
        ],
        [
          0.25,
          0.025,
          0.075,
          0.02,
          0.0375,
          1.0,
          0.025,
          0.0,
          0.0625
        ],
        [
          0.1,
          0.01,
          0.03,
          0.008,
          0.015,
          0.025,
          1.0,
          0.0,
          0.025
        ],
        [
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          1.0,
          0.0
        ],
        [
          0.25,
          0.1,
          0.15,
          0.02,
          0.0375,
          0.0625,
          0.025,
          0.0,
          1.0
        ]
      ],
      "residual_correlation": null,
      "scale": "latent",
      "targets": [
        {
          "intraclass_correlation": 0.05,
          "variable": "baseline_risk"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "age_at_index"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "secondary_risk"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "sex_code"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "body_mass_index"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "c_reactive_protein"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "current_smoker"
        },
        {
          "intraclass_correlation": 0.0,
          "variable": "diagnosis_duration_months_fraction"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "latent_risk"
        }
      ]
    },
    "baseline_measurements": [
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "disease_measure",
        "field_id": "baseline_das28_score",
        "label": "Baseline Disease Activity Score in 28 joints",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 0.01
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "baseline_risk",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": 10.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "DAS28 points",
        "value_type": "continuous"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "demographic",
        "field_id": "age_years",
        "label": "Age at treatment initiation",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "age_at_index",
        "source_ids": [],
        "support": {
          "lower": 18.0,
          "upper": 95.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "years",
        "value_type": "integer"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "treatment",
        "field_id": "prior_biologic_dmard_use",
        "label": "Prior biologic DMARD use before baseline",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "secondary_risk",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": 1.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "0=no, 1=yes",
        "value_type": "integer"
      },
      {
        "allowed_values": null,
        "categories": [
          "male",
          "female"
        ],
        "evidence_role": "mechanism_relative",
        "family": "demographic",
        "field_id": "sex",
        "label": "Recorded sex",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Recorded baseline sex",
          "missing_value": "",
          "resolution": null
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [
          0.0,
          1.0
        ],
        "source_direction": 1,
        "source_field_id": "sex_code",
        "source_ids": [],
        "support": null,
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "category",
        "value_type": "categorical"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "anthropometric",
        "field_id": "baseline_body_mass_index",
        "label": "Body mass index",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 0.1
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "body_mass_index",
        "source_ids": [],
        "support": {
          "lower": 16.0,
          "upper": 50.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "kg/m2",
        "value_type": "continuous"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "laboratory",
        "field_id": "baseline_c_reactive_protein",
        "label": "C-reactive protein",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 0.1
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "c_reactive_protein",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": null
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "mg/L",
        "value_type": "continuous"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "demographic",
        "field_id": "baseline_current_smoker",
        "label": "Current cigarette smoking",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "current_smoker",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": 1.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "0=no, 1=yes",
        "value_type": "integer"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "disease_measure",
        "field_id": "baseline_diagnosis_duration_months",
        "label": "Time since diagnosis",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "diagnosis_duration_months",
        "source_ids": [],
        "support": {
          "lower": 3.0,
          "upper": null
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "months",
        "value_type": "integer"
      }
    ],
    "baseline_outcome_intercept": 3.2,
    "baseline_safety_probability": 0.04,
    "candidates": [
      {
        "asset_id": "control",
        "assignment_intercept": 0.0,
        "effect_modifiers": [],
        "outcome_effect": 0.0,
        "regimen_response": null,
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.0
      },
      {
        "asset_id": "mrd-88811",
        "assignment_intercept": 0.008755392898435254,
        "effect_modifiers": [
          {
            "difference_per_sd": -0.01910887458578114,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": 0.04863335774990547,
        "regimen_response": {
          "half_maximal_relative_exposure": 0.2843148622249691,
          "response_half_time_fraction": 0.21939971977424425,
          "safety_log_odds_per_log_exposure": 0.2107370207184297
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": 0.024661023330592637,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.007588007178643889,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": 0.01707301615194875,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.0018970017946609722,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": 0.0018970017946609722,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": 0.005691005383982916,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": 0.0018970017946609722,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": 0.005691005383982916,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.03469800260871611
      },
      {
        "asset_id": "mrd-93853",
        "assignment_intercept": 0.044027520022581354,
        "effect_modifiers": [
          {
            "difference_per_sd": 0.11814483450893905,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": -0.9576713582135944,
        "regimen_response": {
          "half_maximal_relative_exposure": 0.7118721248594774,
          "response_half_time_fraction": 0.16490782393628,
          "safety_log_odds_per_log_exposure": 0.15475206893887838
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": 0.12401084806360417,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.038157184019570516,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": 0.08585366404403365,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.009539296004892629,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": 0.009539296004892629,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": 0.02861788801467788,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": 0.009539296004892629,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": 0.02861788801467788,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.013781938374036391
      },
      {
        "asset_id": "mrd-81623",
        "assignment_intercept": 0.046015824156939784,
        "effect_modifiers": [
          {
            "difference_per_sd": 0.03221759584306516,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": 0.1841232963457485,
        "regimen_response": {
          "half_maximal_relative_exposure": 0.7499170204618614,
          "response_half_time_fraction": 0.2114293743299706,
          "safety_log_odds_per_log_exposure": 0.55662512759343
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": 0.12961123804204708,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.03988038093601449,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": 0.0897308571060326,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.009970095234003622,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": 0.009970095234003622,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": 0.029910285702010864,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": 0.009970095234003622,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": 0.029910285702010864,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.004143477474121769
      }
    ],
    "cohort_id": "development.tdw-ed4fcb8dc68f",
    "control_asset_id": "control",
    "count_dispersion": null,
    "outcome_context_effects": [
      {
        "coefficients": [
          0.20582028224408563,
          -0.01692541892213629,
          -0.29313750225243956,
          0.22353634215674884,
          0.0905433706732108,
          0.12519599700182385,
          -0.3434469025095589,
          0.05310170409311664,
          0.021633227446300318,
          -0.12517209467785428,
          -0.07775467560177764,
          0.01178259824272434,
          0.2375826439192201,
          0.11316793318180243,
          0.25662320461582416,
          -0.6490414182042051,
          0.22593336203985978,
          0.4119809717228671,
          0.09507439251425251,
          0.33728505291114524,
          -0.2351109511536993,
          0.25147671501450775,
          0.07714106631753727,
          0.09250993635892397,
          -0.08664368544829525,
          0.0876187707260141,
          0.3704446121101511,
          0.05526786510248358,
          0.6978160294417264,
          -0.038098454582397426,
          -0.014093798625086779,
          -0.2048660403683842,
          0.26035143828288676,
          0.5759493549400692,
          -0.22221209580343687,
          0.242232343870757,
          -0.29677739462646546,
          -0.027171214552145724,
          -0.3389443950082499,
          0.14708131818371595,
          -0.5241685809018017,
          0.44932903371035654,
          -0.20839858244568088,
          0.03305157092424545,
          -0.16569913620863233,
          0.1071353733976882,
          0.04462217821527862,
          0.3278735760976969,
          -0.17156228573566118,
          -0.22667490969122644,
          -0.09502975367212314,
          0.3690781367567268,
          -0.06626438014357437,
          0.2253785074763863,
          0.2937179652995181,
          -0.19383997332433786,
          0.008712878718647975,
          -0.14617357101724462,
          -0.26436636333188457,
          0.1053795783080196,
          0.4476410416310033,
          0.02556688973370148,
          0.03270727843037117,
          0.4395706596513047,
          -0.32001340354831576,
          -0.5189524670430169,
          -0.02538940769274097,
          0.3987262886149964,
          -0.07683344153791263,
          -0.14676999884152322,
          -0.08921704846380882,
          -0.2369955558083563,
          0.02158520593574007,
          0.12814944542081871,
          -0.4252393550253394,
          -0.007822244290465529,
          0.26745262657216573,
          0.27284211527934804,
          0.20263851608279806,
          0.028944669754243545
        ],
        "effect_id": "site_context",
        "effect_type": "group_varying",
        "grouping_variable": "site_id",
        "input_variable": null,
        "levels": [
          "site_001",
          "site_002",
          "site_003",
          "site_004",
          "site_005",
          "site_006",
          "site_007",
          "site_008",
          "site_009",
          "site_010",
          "site_011",
          "site_012",
          "site_013",
          "site_014",
          "site_015",
          "site_016",
          "site_017",
          "site_018",
          "site_019",
          "site_020",
          "site_021",
          "site_022",
          "site_023",
          "site_024",
          "site_025",
          "site_026",
          "site_027",
          "site_028",
          "site_029",
          "site_030",
          "site_031",
          "site_032",
          "site_033",
          "site_034",
          "site_035",
          "site_036",
          "site_037",
          "site_038",
          "site_039",
          "site_040",
          "site_041",
          "site_042",
          "site_043",
          "site_044",
          "site_045",
          "site_046",
          "site_047",
          "site_048",
          "site_049",
          "site_050",
          "site_051",
          "site_052",
          "site_053",
          "site_054",
          "site_055",
          "site_056",
          "site_057",
          "site_058",
          "site_059",
          "site_060",
          "site_061",
          "site_062",
          "site_063",
          "site_064",
          "site_065",
          "site_066",
          "site_067",
          "site_068",
          "site_069",
          "site_070",
          "site_071",
          "site_072",
          "site_073",
          "site_074",
          "site_075",
          "site_076",
          "site_077",
          "site_078",
          "site_079",
          "site_080"
        ],
        "unit": "outcome unit"
      }
    ],
    "outcome_lower_bound": 0.0,
    "outcome_rounding_increment": 0.01,
    "outcome_standard_deviation": 1.32,
    "outcome_upper_bound": 10.0,
    "participant_count": 300,
    "random_stream_id": "trialdev_observational_population_v1_tdw_ed4fcb8dc68f",
    "risk_factor_correlation_matrix": [
      [
        1.0,
        0.1,
        0.3,
        0.08,
        0.15,
        0.25,
        0.1,
        0.0,
        0.25
      ],
      [
        0.1,
        1.0,
        0.2,
        0.008,
        0.015,
        0.025,
        0.01,
        0.0,
        0.1
      ],
      [
        0.3,
        0.2,
        1.0,
        0.024,
        0.045,
        0.075,
        0.03,
        0.0,
        0.15
      ],
      [
        0.08,
        0.008,
        0.024,
        1.0,
        0.012,
        0.02,
        0.008,
        0.0,
        0.02
      ],
      [
        0.15,
        0.015,
        0.045,
        0.012,
        1.0,
        0.0375,
        0.015,
        0.0,
        0.0375
      ],
      [
        0.25,
        0.025,
        0.075,
        0.02,
        0.0375,
        1.0,
        0.025,
        0.0,
        0.0625
      ],
      [
        0.1,
        0.01,
        0.03,
        0.008,
        0.015,
        0.025,
        1.0,
        0.0,
        0.025
      ],
      [
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0
      ],
      [
        0.25,
        0.1,
        0.15,
        0.02,
        0.0375,
        0.0625,
        0.025,
        0.0,
        1.0
      ]
    ],
    "risk_factor_dependence_scale": "latent",
    "risk_factors": [
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": 2.0,
          "mean": 5.2,
          "standard_deviation": 1.0,
          "upper": 9.0
        },
        "outcome_difference_per_sd": 0.8,
        "role": "measured",
        "safety_log_odds_per_sd": 0.0,
        "unit": "DAS28 points",
        "variable_id": "baseline_risk"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": 18.0,
          "mean": 55.0,
          "standard_deviation": 12.0,
          "upper": 85.0
        },
        "outcome_difference_per_sd": 0.1,
        "role": "measured",
        "safety_log_odds_per_sd": 0.35,
        "unit": "years",
        "variable_id": "age_at_index"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "bernoulli",
          "lower": null,
          "mean": 0.35,
          "standard_deviation": 0.47696960070847283,
          "upper": null
        },
        "outcome_difference_per_sd": 0.25,
        "role": "measured",
        "safety_log_odds_per_sd": 0.3,
        "unit": "indicator",
        "variable_id": "secondary_risk"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "bernoulli",
          "lower": null,
          "mean": 0.8,
          "standard_deviation": 0.39999999999999997,
          "upper": null
        },
        "outcome_difference_per_sd": 0.08,
        "role": "measured",
        "safety_log_odds_per_sd": 0.03,
        "unit": "indicator",
        "variable_id": "sex_code"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": 16.0,
          "mean": 28.0,
          "standard_deviation": 5.0,
          "upper": 50.0
        },
        "outcome_difference_per_sd": 0.08,
        "role": "measured",
        "safety_log_odds_per_sd": 0.1,
        "unit": "kg/m2",
        "variable_id": "body_mass_index"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "log_normal",
          "lower": null,
          "mean": 12.0,
          "standard_deviation": 15.0,
          "upper": null
        },
        "outcome_difference_per_sd": 0.15,
        "role": "measured",
        "safety_log_odds_per_sd": 0.1,
        "unit": "mg/L",
        "variable_id": "c_reactive_protein"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "bernoulli",
          "lower": null,
          "mean": 0.2,
          "standard_deviation": 0.4,
          "upper": null
        },
        "outcome_difference_per_sd": 0.08,
        "role": "measured",
        "safety_log_odds_per_sd": 0.15,
        "unit": "0=no, 1=yes",
        "variable_id": "current_smoker"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "beta",
          "lower": null,
          "mean": 0.20516129032258063,
          "standard_deviation": 0.18686362286581598,
          "upper": null
        },
        "outcome_difference_per_sd": 0.0,
        "role": "latent",
        "safety_log_odds_per_sd": 0.0,
        "unit": "fraction",
        "variable_id": "diagnosis_duration_months_fraction"
      },
      {
        "derivation": {
          "effects": [
            {
              "coefficient": -195.0,
              "effect_id": "minimum_diagnosis_age",
              "effect_type": "main",
              "input_variable": "diagnosis_duration_months_fraction",
              "unit": "months"
            },
            {
              "coefficient": 12.0,
              "effect_id": "eligible_lifetime",
              "effect_type": "interaction",
              "input_variables": [
                "age_at_index",
                "diagnosis_duration_months_fraction"
              ],
              "unit": "months"
            }
          ],
          "hierarchical_effect_correlations": [],
          "inputs": [
            "diagnosis_duration_months_fraction",
            "age_at_index"
          ],
          "learned": null,
          "measurement_model": null,
          "mechanism_id": "diagnosis_duration_months",
          "mechanism_type": "derived_effect",
          "nominal_calibration": null,
          "nominal_logits": null,
          "observation_rule": null,
          "output": "diagnosis_duration_months",
          "output_levels": null,
          "output_unit": "months",
          "parameters": [
            {
              "input_variable": null,
              "parameter_id": "intercept",
              "role": "intercept",
              "source": "fixed",
              "unit": "months",
              "value": 3.0
            }
          ],
          "probability_bounds": null,
          "residual_scale": null,
          "stochastic": false
        },
        "distribution": {
          "family": "normal",
          "lower": null,
          "mean": 98.39999999999999,
          "standard_deviation": 95.64,
          "upper": null
        },
        "outcome_difference_per_sd": 0.165,
        "role": "measured",
        "safety_log_odds_per_sd": 0.1,
        "unit": "months",
        "variable_id": "diagnosis_duration_months"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": null,
          "mean": 0.0,
          "standard_deviation": 1.0,
          "upper": null
        },
        "outcome_difference_per_sd": 0.0,
        "role": "latent",
        "safety_log_odds_per_sd": 0.0,
        "unit": "standardized latent-risk unit",
        "variable_id": "latent_risk"
      }
    ],
    "root_seed": 4660344060105665361,
    "safety_context_effects": [
      {
        "coefficients": [
          0.19490557030689926,
          -0.016027858827780576,
          -0.27759233167844655,
          0.21168214219389092,
          0.08574182828902538,
          0.11855681534263622,
          -0.32523380919465805,
          0.05028570463363318,
          0.020486010839299542,
          -0.1185341805661499,
          -0.07363132159259246,
          0.011157763487428352,
          0.22498356431744326,
          0.10716660339185836,
          0.24301439831043953,
          -0.6146225551176184,
          0.21395204738623083,
          0.3901334959496847,
          0.09003256866879972,
          0.3193987243476754,
          -0.22264294616827582,
          0.23814082861222324,
          0.07305025219463757,
          0.08760410640049618,
          -0.08204894455330988,
          0.08297232076327092,
          0.35079982207400673,
          0.05233699346826096,
          0.6608106339410288,
          -0.03607808199090665,
          -0.013346400213150358,
          -0.1940019321670305,
          0.24654492261637,
          0.5454065861174897,
          -0.21042812102598188,
          0.22938668927155018,
          -0.28103919945688016,
          -0.025730316810744055,
          -0.32097007103053965,
          0.13928155131033707,
          -0.49637176221761525,
          0.4255009788923831,
          -0.19734714246750082,
          0.03129883610250516,
          -0.1569120608036291,
          0.10145395208114412,
          0.0422558505826502,
          0.3104863410016069,
          -0.16246428573452762,
          -0.2146542705409341,
          -0.0899902970379954,
          0.34950581132265796,
          -0.06275035998444542,
          0.2134266169283961,
          0.2781420125942406,
          -0.18356058079956236,
          0.008250832119931793,
          -0.13842194225117863,
          -0.2503469349733755,
          0.09979126733713976,
          0.4239025015445107,
          0.024211069823580945,
          0.03097280154391209,
          0.4162600943667658,
          -0.3030429957843899,
          -0.49143226045740235,
          -0.02404299970903501,
          0.3775817127035951,
          -0.07275894085029605,
          -0.13898674132720001,
          -0.0844858413483038,
          -0.22442760966700406,
          0.020440535923996275,
          0.12135364149698741,
          -0.402688783167935,
          -0.0074074283053650845,
          0.25326953273879327,
          0.25837321522665535,
          0.19189253416931634,
          0.027409725146063962
        ],
        "effect_id": "site_safety",
        "effect_type": "group_varying",
        "grouping_variable": "site_id",
        "input_variable": null,
        "levels": [
          "site_001",
          "site_002",
          "site_003",
          "site_004",
          "site_005",
          "site_006",
          "site_007",
          "site_008",
          "site_009",
          "site_010",
          "site_011",
          "site_012",
          "site_013",
          "site_014",
          "site_015",
          "site_016",
          "site_017",
          "site_018",
          "site_019",
          "site_020",
          "site_021",
          "site_022",
          "site_023",
          "site_024",
          "site_025",
          "site_026",
          "site_027",
          "site_028",
          "site_029",
          "site_030",
          "site_031",
          "site_032",
          "site_033",
          "site_034",
          "site_035",
          "site_036",
          "site_037",
          "site_038",
          "site_039",
          "site_040",
          "site_041",
          "site_042",
          "site_043",
          "site_044",
          "site_045",
          "site_046",
          "site_047",
          "site_048",
          "site_049",
          "site_050",
          "site_051",
          "site_052",
          "site_053",
          "site_054",
          "site_055",
          "site_056",
          "site_057",
          "site_058",
          "site_059",
          "site_060",
          "site_061",
          "site_062",
          "site_063",
          "site_064",
          "site_065",
          "site_066",
          "site_067",
          "site_068",
          "site_069",
          "site_070",
          "site_071",
          "site_072",
          "site_073",
          "site_074",
          "site_075",
          "site_076",
          "site_077",
          "site_078",
          "site_079",
          "site_080"
        ],
        "unit": "log_odds"
      }
    ]
  },
  "estimands": [
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-88811.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-88811",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-88811.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-88811",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-93853.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-93853",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-93853.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-93853",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-81623.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-81623",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-81623.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-81623",
      "validation_analysis": null,
      "weighted_log_rank": null
    }
  ]
}
```

</details>

<details><summary>Prospective response process: exact native definition</summary>

```json
{
  "active_endpoint_observation_probability": 0.9821434999101117,
  "attendance_log_odds_per_baseline_sd": -0.2,
  "attendance_log_odds_per_site_sd": -0.3,
  "endpoint_attendance_probability": 0.9768025821695441,
  "endpoint_observation_probability": 0.9708284264586321,
  "measurement_error_standard_deviation": 0.11000000000000001,
  "monotone_dropout": true,
  "observation_log_odds_after_reported_safety_event": -0.75,
  "observation_log_odds_per_baseline_sd": -0.25,
  "observation_log_odds_per_prior_outcome_sd": -0.5,
  "outcome_autocorrelation": 0.6,
  "population_risk_profiles": [
    {
      "mean": 5.95,
      "population": "higher_baseline_risk",
      "standard_deviation": 1.0
    }
  ],
  "randomization_block_size": 4,
  "recurrent_loss_log_hazard_per_baseline_sd": 0.0,
  "recurrent_loss_log_hazard_per_prior_event": 0.0,
  "recurrent_loss_to_follow_up_hazard_per_day": 0.0,
  "safety_endpoint": {
    "event_id": "infection_aesi",
    "events": [
      {
        "category": "infection",
        "coding_system": "Protocol AESI dictionary v1",
        "dictionary_term": "Upper respiratory tract infection",
        "discontinuation_severities": [
          "severe"
        ],
        "event_id": "respiratory_infection",
        "hazard_share": 0.65,
        "medical_code": "Upper respiratory tract infection",
        "resolution_probability_per_contact": 0.8,
        "severity_levels": [
          {
            "level": "mild_or_moderate",
            "probability": 0.98,
            "serious": false,
            "seriousness_criteria": []
          },
          {
            "level": "severe",
            "probability": 0.02,
            "serious": true,
            "seriousness_criteria": [
              "AESHOSP"
            ]
          }
        ]
      },
      {
        "category": "infection",
        "coding_system": "Protocol AESI dictionary v1",
        "dictionary_term": "Urinary tract infection",
        "discontinuation_severities": [
          "severe"
        ],
        "event_id": "urinary_infection",
        "hazard_share": 0.35,
        "medical_code": "Urinary tract infection",
        "resolution_probability_per_contact": 0.6,
        "severity_levels": [
          {
            "level": "mild_or_moderate",
            "probability": 0.95,
            "serious": false,
            "seriousness_criteria": []
          },
          {
            "level": "severe",
            "probability": 0.05,
            "serious": true,
            "seriousness_criteria": [
              "AESHOSP"
            ]
          }
        ]
      }
    ]
  },
  "treatment_discontinuation_risk": 0.08
}
```

</details>
