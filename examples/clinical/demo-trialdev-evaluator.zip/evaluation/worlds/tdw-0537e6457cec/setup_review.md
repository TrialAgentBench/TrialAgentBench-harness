# Setup review: tdw-0537e6457cec

MERIDIAN rheumatoid-arthritis programme: add-on treatment for rheumatoid arthritis despite conventional therapy

This page reveals evaluator-only simulation assumptions. Read the participant evidence protocol and task request alongside it. The definitions below describe the clinical world; the task's committee_brief.md and authored_programme.json define the actual design space, budget, calendar horizon and sponsor preferences. They are the authority for execution.

The initial cohort supports standardized observed candidate-control associations. These numerical targets describe recorded evidence and do not assert that observational adjustment identifies a causal treatment effect. Measured clinical fields are released; latent factors and counterfactual outcomes remain private.

Prospective evidence comes from a frozen patient population with shared treatment and dose counterfactuals. The agent authors safety, exploration and confirmation studies, including allocation, recruitment, schedules and permitted interim looks. The runtime samples this pool reproducibly and reveals only accrued observations; it performs no native generation during the task. Raw domains and analysis-ready tables represent the same evidence.

Study analyses target the declared population and endpoint window. Terminal development value uses complete-population, final-horizon benefit and safety contrasts in pool/manifest.json, combined with public sponsor preferences and incurred costs and calendar time. An acquired study sample does not replace that terminal target. Stopping is a legitimate decision.

Both analysis streams return estimates and 95% intervals through the common numerical interface. Grading compares those numbers with the declared targets; it does not adjudicate a preferred method or require diagnostic flags. Observational reference precision and source provenance are retained in observational_association_reference.json. Frozen pool records allow separate reconstruction of finite-population prospective contrasts.

These are declared simulation assumptions, not empirical calibration unless the clinical provenance explicitly supplies it. This generated page is not clinical sign-off or evidence that release qualification has passed.

<details><summary>Clinical interpretation and measurement: exact native definition</summary>

```json
{
  "baseline_assignment": [
    {
      "log_odds_ratio_per_sd": 0.65,
      "variable_id": "baseline_risk"
    },
    {
      "log_odds_ratio_per_sd": -0.2,
      "variable_id": "age_at_index"
    },
    {
      "log_odds_ratio_per_sd": 0.45,
      "variable_id": "secondary_risk"
    },
    {
      "log_odds_ratio_per_sd": 0.05,
      "variable_id": "sex_code"
    },
    {
      "log_odds_ratio_per_sd": 0.05,
      "variable_id": "body_mass_index"
    },
    {
      "log_odds_ratio_per_sd": 0.15,
      "variable_id": "c_reactive_protein"
    },
    {
      "log_odds_ratio_per_sd": 0.05,
      "variable_id": "current_smoker"
    },
    {
      "log_odds_ratio_per_sd": 0.0,
      "variable_id": "diagnosis_duration_months_fraction"
    },
    {
      "log_odds_ratio_per_sd": 0.15,
      "variable_id": "diagnosis_duration_months"
    }
  ],
  "baseline_factors": [
    {
      "derivation": null,
      "distribution": {
        "family": "normal",
        "lower": 2.0,
        "mean": 5.2,
        "standard_deviation": 1.0,
        "upper": 9.0
      },
      "outcome_difference_per_sd": 0.8,
      "role": "measured",
      "safety_log_odds_per_sd": 0.0,
      "unit": "DAS28 points",
      "variable_id": "baseline_risk"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "normal",
        "lower": 18.0,
        "mean": 55.0,
        "standard_deviation": 12.0,
        "upper": 85.0
      },
      "outcome_difference_per_sd": 0.1,
      "role": "measured",
      "safety_log_odds_per_sd": 0.35,
      "unit": "years",
      "variable_id": "age_at_index"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "bernoulli",
        "lower": null,
        "mean": 0.35,
        "standard_deviation": 0.47696960070847283,
        "upper": null
      },
      "outcome_difference_per_sd": 0.25,
      "role": "measured",
      "safety_log_odds_per_sd": 0.3,
      "unit": "indicator",
      "variable_id": "secondary_risk"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "bernoulli",
        "lower": null,
        "mean": 0.8,
        "standard_deviation": 0.39999999999999997,
        "upper": null
      },
      "outcome_difference_per_sd": 0.08,
      "role": "measured",
      "safety_log_odds_per_sd": 0.03,
      "unit": "indicator",
      "variable_id": "sex_code"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "normal",
        "lower": 16.0,
        "mean": 28.0,
        "standard_deviation": 5.0,
        "upper": 50.0
      },
      "outcome_difference_per_sd": 0.08,
      "role": "measured",
      "safety_log_odds_per_sd": 0.1,
      "unit": "kg/m2",
      "variable_id": "body_mass_index"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "log_normal",
        "lower": null,
        "mean": 12.0,
        "standard_deviation": 15.0,
        "upper": null
      },
      "outcome_difference_per_sd": 0.15,
      "role": "measured",
      "safety_log_odds_per_sd": 0.1,
      "unit": "mg/L",
      "variable_id": "c_reactive_protein"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "bernoulli",
        "lower": null,
        "mean": 0.2,
        "standard_deviation": 0.4,
        "upper": null
      },
      "outcome_difference_per_sd": 0.08,
      "role": "measured",
      "safety_log_odds_per_sd": 0.15,
      "unit": "0=no, 1=yes",
      "variable_id": "current_smoker"
    },
    {
      "derivation": null,
      "distribution": {
        "family": "beta",
        "lower": null,
        "mean": 0.20516129032258063,
        "standard_deviation": 0.18686362286581598,
        "upper": null
      },
      "outcome_difference_per_sd": 0.0,
      "role": "latent",
      "safety_log_odds_per_sd": 0.0,
      "unit": "fraction",
      "variable_id": "diagnosis_duration_months_fraction"
    },
    {
      "derivation": {
        "effects": [
          {
            "coefficient": -195.0,
            "effect_id": "minimum_diagnosis_age",
            "effect_type": "main",
            "input_variable": "diagnosis_duration_months_fraction",
            "unit": "months"
          },
          {
            "coefficient": 12.0,
            "effect_id": "eligible_lifetime",
            "effect_type": "interaction",
            "input_variables": [
              "age_at_index",
              "diagnosis_duration_months_fraction"
            ],
            "unit": "months"
          }
        ],
        "hierarchical_effect_correlations": [],
        "inputs": [
          "diagnosis_duration_months_fraction",
          "age_at_index"
        ],
        "learned": null,
        "measurement_model": null,
        "mechanism_id": "diagnosis_duration_months",
        "mechanism_type": "derived_effect",
        "nominal_calibration": null,
        "nominal_logits": null,
        "observation_rule": null,
        "output": "diagnosis_duration_months",
        "output_levels": null,
        "output_unit": "months",
        "parameters": [
          {
            "input_variable": null,
            "parameter_id": "intercept",
            "role": "intercept",
            "source": "fixed",
            "unit": "months",
            "value": 3.0
          }
        ],
        "probability_bounds": null,
        "residual_scale": null,
        "stochastic": false
      },
      "distribution": {
        "family": "normal",
        "lower": null,
        "mean": 98.39999999999999,
        "standard_deviation": 95.64,
        "upper": null
      },
      "outcome_difference_per_sd": 0.165,
      "role": "measured",
      "safety_log_odds_per_sd": 0.1,
      "unit": "months",
      "variable_id": "diagnosis_duration_months"
    }
  ],
  "baseline_fields": [
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "disease_measure",
      "field_id": "baseline_das28_score",
      "label": "Baseline Disease Activity Score in 28 joints",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 0.01
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "baseline_risk",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": 10.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "DAS28 points",
      "value_type": "continuous"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "demographic",
      "field_id": "age_years",
      "label": "Age at treatment initiation",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "age_at_index",
      "source_ids": [],
      "support": {
        "lower": 18.0,
        "upper": 95.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "years",
      "value_type": "integer"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "treatment",
      "field_id": "prior_biologic_dmard_use",
      "label": "Prior biologic DMARD use before baseline",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "secondary_risk",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": 1.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "0=no, 1=yes",
      "value_type": "integer"
    },
    {
      "allowed_values": null,
      "categories": [
        "male",
        "female"
      ],
      "evidence_role": "mechanism_relative",
      "family": "demographic",
      "field_id": "sex",
      "label": "Recorded sex",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Recorded baseline sex",
        "missing_value": "",
        "resolution": null
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [
        0.0,
        1.0
      ],
      "source_direction": 1,
      "source_field_id": "sex_code",
      "source_ids": [],
      "support": null,
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "category",
      "value_type": "categorical"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "anthropometric",
      "field_id": "baseline_body_mass_index",
      "label": "Body mass index",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 0.1
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "body_mass_index",
      "source_ids": [],
      "support": {
        "lower": 16.0,
        "upper": 50.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "kg/m2",
      "value_type": "continuous"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "laboratory",
      "field_id": "baseline_c_reactive_protein",
      "label": "C-reactive protein",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 0.1
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "c_reactive_protein",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": null
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "mg/L",
      "value_type": "continuous"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "demographic",
      "field_id": "baseline_current_smoker",
      "label": "Current cigarette smoking",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "current_smoker",
      "source_ids": [],
      "support": {
        "lower": 0.0,
        "upper": 1.0
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "0=no, 1=yes",
      "value_type": "integer"
    },
    {
      "allowed_values": null,
      "categories": [],
      "evidence_role": "mechanism_relative",
      "family": "disease_measure",
      "field_id": "baseline_diagnosis_duration_months",
      "label": "Time since diagnosis",
      "measurement": {
        "artifact_modes": [],
        "device_or_assay": null,
        "error": {
          "error_model": "exact"
        },
        "method": "Protocol-defined baseline assessment",
        "missing_value": "",
        "resolution": 1.0
      },
      "offset": 0.0,
      "role": "covariate",
      "scale": 1.0,
      "settings": [
        "observational",
        "trial"
      ],
      "source_codes": [],
      "source_direction": 1,
      "source_field_id": "diagnosis_duration_months",
      "source_ids": [],
      "support": {
        "lower": 3.0,
        "upper": null
      },
      "timing": {
        "reference": "baseline",
        "repeatable": false,
        "window_unit": null
      },
      "unit": "months",
      "value_type": "integer"
    }
  ],
  "candidate_class": "oral immunomodulatory candidates",
  "candidate_code_prefix": "MRD",
  "candidate_descriptor": "oral immunomodulatory candidate",
  "candidate_labels": [
    "MRD-89991",
    "MRD-82213",
    "MRD-60468",
    "MRD-84607",
    "MRD-11523"
  ],
  "clinical_setting": "add-on treatment for rheumatoid arthritis despite conventional therapy",
  "comparator_label": "standard care",
  "confirmatory_assessment_days": 168,
  "count_dispersion": null,
  "endpoint_support_lower": 0.0,
  "endpoint_support_upper": 10.0,
  "exploratory_assessment_days": 84,
  "maximum_acceptable_safety_risk_difference": 0.03,
  "observational_assessment_days": 168,
  "outcome_field_id": "das28_score_end_of_follow_up",
  "outcome_label": "Disease Activity Score in 28 joints at the endpoint assessment",
  "outcome_link_scale": 1.1,
  "outcome_object": "Rheumatoid arthritis",
  "outcome_offset": 1.0,
  "outcome_reference_difference": 0.6,
  "outcome_reference_interpretation": "A 0.6-point within-person improvement is the lower EULAR moderate-response threshold; it is an interpretation anchor, not a required between-group effect.",
  "outcome_rounding_increment": 0.01,
  "outcome_scale": 1.1,
  "outcome_unit": "DAS28 points",
  "population": "adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy",
  "profile_id": "rheumatoid_arthritis",
  "programme_name": "MERIDIAN rheumatoid-arthritis programme",
  "recruitment_countries": [
    "USA",
    "CAN",
    "GBR",
    "DEU"
  ],
  "recruitment_subsets": [
    {
      "criteria": [
        {
          "column": "prior_biologic_dmard_use",
          "operator": "greater_than",
          "value": 0.0
        }
      ],
      "label": "Prior biologic DMARD use",
      "subset_id": "prior_biologic"
    },
    {
      "criteria": [
        {
          "column": "baseline_c_reactive_protein",
          "operator": "greater_than_or_equal",
          "value": 10.0
        },
        {
          "column": "baseline_diagnosis_duration_months",
          "operator": "greater_than_or_equal",
          "value": 60.0
        }
      ],
      "label": "CRP at least 10 mg/L and diagnosis for at least five years",
      "subset_id": "inflammation_longstanding"
    }
  ],
  "regimens": [
    {
      "amount_mg": 15.0,
      "dose": "standard",
      "interval_days": 1,
      "route": "oral"
    },
    {
      "amount_mg": 30.0,
      "dose": "intensified",
      "interval_days": 1,
      "route": "oral"
    }
  ],
  "registry_family_id": "TD-RA",
  "rescue_event": {
    "arm_coefficients": [
      {
        "arm_id": "control",
        "value": 0.0
      },
      {
        "arm_id": "active",
        "value": 0.0
      }
    ],
    "baseline_coefficient": 0.3,
    "baseline_variable": "baseline_risk",
    "cluster_probability_concentration": null,
    "cluster_reference_probability": null,
    "effects": [],
    "event_id": "rescue_antirheumatic_therapy",
    "event_type": "intercurrent",
    "exposure_action": "no_change",
    "hierarchical_effect_correlations": [],
    "intercept": -3.0,
    "kind": "rescue_medication",
    "learned_effect": null,
    "occurrence_timing": "within_contact_interval",
    "outcome_shift": -0.25,
    "recurrent": false,
    "risk_reference_duration": 70.0,
    "risk_window_end": null,
    "risk_window_start": 98.0,
    "state_coefficients": [],
    "target_arm": null,
    "time_coefficient": 0.0,
    "withdrawal_reason": null,
    "withdrawal_reason_text": null
  },
  "residual_confounding_context": "Routine-care baseline records include DAS28, age and prior biologic DMARD use; treatment was not randomized.",
  "risk_factor_correlation_matrix": [
    [
      1.0,
      0.1,
      0.3,
      0.08,
      0.15,
      0.25,
      0.1,
      0.0,
      0.25
    ],
    [
      0.1,
      1.0,
      0.2,
      0.008,
      0.015,
      0.025,
      0.01,
      0.0,
      0.1
    ],
    [
      0.3,
      0.2,
      1.0,
      0.024,
      0.045,
      0.075,
      0.03,
      0.0,
      0.15
    ],
    [
      0.08,
      0.008,
      0.024,
      1.0,
      0.012,
      0.02,
      0.008,
      0.0,
      0.02
    ],
    [
      0.15,
      0.015,
      0.045,
      0.012,
      1.0,
      0.0375,
      0.015,
      0.0,
      0.0375
    ],
    [
      0.25,
      0.025,
      0.075,
      0.02,
      0.0375,
      1.0,
      0.025,
      0.0,
      0.0625
    ],
    [
      0.1,
      0.01,
      0.03,
      0.008,
      0.015,
      0.025,
      1.0,
      0.0,
      0.025
    ],
    [
      0.0,
      0.0,
      0.0,
      0.0,
      0.0,
      0.0,
      0.0,
      1.0,
      0.0
    ],
    [
      0.25,
      0.1,
      0.15,
      0.02,
      0.0375,
      0.0625,
      0.025,
      0.0,
      1.0
    ]
  ],
  "risk_factor_dependence_scale": "latent",
  "safety_event_id": "infection_aesi",
  "safety_events": [
    {
      "category": "infection",
      "coding_system": "Protocol AESI dictionary v1",
      "dictionary_term": "Upper respiratory tract infection",
      "discontinuation_severities": [
        "severe"
      ],
      "event_id": "respiratory_infection",
      "hazard_share": 0.65,
      "medical_code": "Upper respiratory tract infection",
      "resolution_probability_per_contact": 0.8,
      "severity_levels": [
        {
          "level": "mild_or_moderate",
          "probability": 0.98,
          "serious": false,
          "seriousness_criteria": []
        },
        {
          "level": "severe",
          "probability": 0.02,
          "serious": true,
          "seriousness_criteria": [
            "AESHOSP"
          ]
        }
      ]
    },
    {
      "category": "infection",
      "coding_system": "Protocol AESI dictionary v1",
      "dictionary_term": "Urinary tract infection",
      "discontinuation_severities": [
        "severe"
      ],
      "event_id": "urinary_infection",
      "hazard_share": 0.35,
      "medical_code": "Urinary tract infection",
      "resolution_probability_per_contact": 0.6,
      "severity_levels": [
        {
          "level": "mild_or_moderate",
          "probability": 0.95,
          "serious": false,
          "seriousness_criteria": []
        },
        {
          "level": "severe",
          "probability": 0.05,
          "serious": true,
          "seriousness_criteria": [
            "AESHOSP"
          ]
        }
      ]
    }
  ],
  "safety_field_id": "infection_aesi_end_of_follow_up",
  "safety_label": "treatment-emergent infection of special interest by the endpoint assessment",
  "screen_failure_fraction": 0.4,
  "screening_candidates_per_site_month": 13.33,
  "site_activation_days": 120,
  "site_case_mix_latent_icc": 0.05,
  "site_outcome_standard_deviation": 0.264,
  "site_safety_log_odds_standard_deviation": 0.25,
  "source_ids": [
    "TAB-SRC-068",
    "TAB-SRC-094"
  ],
  "study_options": [
    {
      "cluster_size": null,
      "cost": 7.5,
      "design": "parallel_group",
      "dose": "standard",
      "duration_days": 126,
      "endpoint_assessment_days": 84,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 300,
      "phase": "exploratory",
      "population": "all_eligible",
      "study_id": "ra_exploratory_all_eligible"
    },
    {
      "cluster_size": null,
      "cost": 9.0,
      "design": "parallel_group",
      "dose": "intensified",
      "duration_days": 126,
      "endpoint_assessment_days": 84,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 160,
      "phase": "exploratory",
      "population": "higher_baseline_risk",
      "study_id": "ra_exploratory_higher_risk"
    },
    {
      "cluster_size": null,
      "cost": 20.0,
      "design": "parallel_group",
      "dose": "standard",
      "duration_days": 224,
      "endpoint_assessment_days": 168,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 1000,
      "phase": "confirmatory",
      "population": "all_eligible",
      "study_id": "ra_confirmatory_all_eligible"
    },
    {
      "cluster_size": null,
      "cost": 24.5,
      "design": "parallel_group",
      "dose": "standard",
      "duration_days": 224,
      "endpoint_assessment_days": 168,
      "endpoints": [
        "clinical_outcome",
        "safety_risk"
      ],
      "intracluster_correlation": null,
      "participant_count": 640,
      "phase": "confirmatory",
      "population": "higher_baseline_risk",
      "study_id": "ra_confirmatory_higher_risk"
    }
  ],
  "therapeutic_area": "rheumatology",
  "treatment_discontinuation_risk": 0.08,
  "typical_outcome_effect": -1.0
}
```

</details>

<details><summary>Observational world and information: exact native definition</summary>

```json
{
  "cohort": {
    "baseline_context_features": [
      {
        "encoding": "label",
        "quantity": {
          "levels": [
            "USA",
            "CAN",
            "GBR",
            "DEU"
          ],
          "probabilities": [
            0.2645161290322581,
            0.24516129032258066,
            0.25161290322580643,
            0.23870967741935487
          ],
          "quantity_type": "categorical_distribution"
        },
        "role": "baseline",
        "variable_id": "country_code"
      },
      {
        "encoding": "label",
        "quantity": {
          "distributions": [
            {
              "levels": [
                "site_001",
                "site_005",
                "site_009",
                "site_013",
                "site_017",
                "site_021",
                "site_025",
                "site_029",
                "site_033",
                "site_037",
                "site_041",
                "site_045",
                "site_049",
                "site_053",
                "site_057",
                "site_061",
                "site_065",
                "site_069",
                "site_073",
                "site_077"
              ],
              "parent_level": "USA",
              "probabilities": [
                0.048780487804878044,
                0.07317073170731707,
                0.024390243902439022,
                0.07317073170731707,
                0.048780487804878044,
                0.048780487804878044,
                0.048780487804878044,
                0.07317073170731707,
                0.048780487804878044,
                0.048780487804878044,
                0.07317073170731707,
                0.07317073170731707,
                0.048780487804878044,
                0.024390243902439022,
                0.024390243902439022,
                0.048780487804878044,
                0.024390243902439022,
                0.048780487804878044,
                0.024390243902439022,
                0.07317073170731707
              ]
            },
            {
              "levels": [
                "site_002",
                "site_006",
                "site_010",
                "site_014",
                "site_018",
                "site_022",
                "site_026",
                "site_030",
                "site_034",
                "site_038",
                "site_042",
                "site_046",
                "site_050",
                "site_054",
                "site_058",
                "site_062",
                "site_066",
                "site_070",
                "site_074",
                "site_078"
              ],
              "parent_level": "CAN",
              "probabilities": [
                0.05263157894736842,
                0.05263157894736842,
                0.07894736842105264,
                0.02631578947368421,
                0.05263157894736842,
                0.05263157894736842,
                0.02631578947368421,
                0.07894736842105264,
                0.02631578947368421,
                0.02631578947368421,
                0.07894736842105264,
                0.02631578947368421,
                0.07894736842105264,
                0.05263157894736842,
                0.05263157894736842,
                0.05263157894736842,
                0.05263157894736842,
                0.05263157894736842,
                0.02631578947368421,
                0.05263157894736842
              ]
            },
            {
              "levels": [
                "site_003",
                "site_007",
                "site_011",
                "site_015",
                "site_019",
                "site_023",
                "site_027",
                "site_031",
                "site_035",
                "site_039",
                "site_043",
                "site_047",
                "site_051",
                "site_055",
                "site_059",
                "site_063",
                "site_067",
                "site_071",
                "site_075",
                "site_079"
              ],
              "parent_level": "GBR",
              "probabilities": [
                0.05128205128205128,
                0.07692307692307693,
                0.02564102564102564,
                0.02564102564102564,
                0.05128205128205128,
                0.05128205128205128,
                0.05128205128205128,
                0.05128205128205128,
                0.07692307692307693,
                0.05128205128205128,
                0.07692307692307693,
                0.02564102564102564,
                0.07692307692307693,
                0.07692307692307693,
                0.02564102564102564,
                0.05128205128205128,
                0.05128205128205128,
                0.02564102564102564,
                0.02564102564102564,
                0.05128205128205128
              ]
            },
            {
              "levels": [
                "site_004",
                "site_008",
                "site_012",
                "site_016",
                "site_020",
                "site_024",
                "site_028",
                "site_032",
                "site_036",
                "site_040",
                "site_044",
                "site_048",
                "site_052",
                "site_056",
                "site_060",
                "site_064",
                "site_068",
                "site_072",
                "site_076",
                "site_080"
              ],
              "parent_level": "DEU",
              "probabilities": [
                0.08108108108108109,
                0.027027027027027025,
                0.027027027027027025,
                0.05405405405405405,
                0.05405405405405405,
                0.05405405405405405,
                0.027027027027027025,
                0.027027027027027025,
                0.08108108108108109,
                0.05405405405405405,
                0.05405405405405405,
                0.027027027027027025,
                0.05405405405405405,
                0.05405405405405405,
                0.08108108108108109,
                0.027027027027027025,
                0.027027027027027025,
                0.05405405405405405,
                0.08108108108108109,
                0.05405405405405405
              ]
            }
          ],
          "parent_variable": "country_code",
          "quantity_type": "nested_categorical_distribution"
        },
        "role": "baseline",
        "variable_id": "site_id"
      }
    ],
    "baseline_grouping": {
      "dependence_id": "baseline_site_case_mix",
      "dependence_type": "hierarchical_random_intercept",
      "group_root_seed": 3381183450060357084,
      "group_variable": "site_id",
      "marginal_dependence": null,
      "random_effect_correlation": [
        [
          1.0,
          0.1,
          0.3,
          0.08,
          0.15,
          0.25,
          0.1,
          0.0,
          0.25
        ],
        [
          0.1,
          1.0,
          0.2,
          0.008,
          0.015,
          0.025,
          0.01,
          0.0,
          0.1
        ],
        [
          0.3,
          0.2,
          1.0,
          0.024,
          0.045,
          0.075,
          0.03,
          0.0,
          0.15
        ],
        [
          0.08,
          0.008,
          0.024,
          1.0,
          0.012,
          0.02,
          0.008,
          0.0,
          0.02
        ],
        [
          0.15,
          0.015,
          0.045,
          0.012,
          1.0,
          0.0375,
          0.015,
          0.0,
          0.0375
        ],
        [
          0.25,
          0.025,
          0.075,
          0.02,
          0.0375,
          1.0,
          0.025,
          0.0,
          0.0625
        ],
        [
          0.1,
          0.01,
          0.03,
          0.008,
          0.015,
          0.025,
          1.0,
          0.0,
          0.025
        ],
        [
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          0.0,
          1.0,
          0.0
        ],
        [
          0.25,
          0.1,
          0.15,
          0.02,
          0.0375,
          0.0625,
          0.025,
          0.0,
          1.0
        ]
      ],
      "residual_correlation": null,
      "scale": "latent",
      "targets": [
        {
          "intraclass_correlation": 0.05,
          "variable": "baseline_risk"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "age_at_index"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "secondary_risk"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "sex_code"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "body_mass_index"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "c_reactive_protein"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "current_smoker"
        },
        {
          "intraclass_correlation": 0.0,
          "variable": "diagnosis_duration_months_fraction"
        },
        {
          "intraclass_correlation": 0.05,
          "variable": "latent_risk"
        }
      ]
    },
    "baseline_measurements": [
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "disease_measure",
        "field_id": "baseline_das28_score",
        "label": "Baseline Disease Activity Score in 28 joints",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 0.01
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "baseline_risk",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": 10.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "DAS28 points",
        "value_type": "continuous"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "demographic",
        "field_id": "age_years",
        "label": "Age at treatment initiation",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "age_at_index",
        "source_ids": [],
        "support": {
          "lower": 18.0,
          "upper": 95.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "years",
        "value_type": "integer"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "treatment",
        "field_id": "prior_biologic_dmard_use",
        "label": "Prior biologic DMARD use before baseline",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "secondary_risk",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": 1.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "0=no, 1=yes",
        "value_type": "integer"
      },
      {
        "allowed_values": null,
        "categories": [
          "male",
          "female"
        ],
        "evidence_role": "mechanism_relative",
        "family": "demographic",
        "field_id": "sex",
        "label": "Recorded sex",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Recorded baseline sex",
          "missing_value": "",
          "resolution": null
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [
          0.0,
          1.0
        ],
        "source_direction": 1,
        "source_field_id": "sex_code",
        "source_ids": [],
        "support": null,
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "category",
        "value_type": "categorical"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "anthropometric",
        "field_id": "baseline_body_mass_index",
        "label": "Body mass index",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 0.1
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "body_mass_index",
        "source_ids": [],
        "support": {
          "lower": 16.0,
          "upper": 50.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "kg/m2",
        "value_type": "continuous"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "laboratory",
        "field_id": "baseline_c_reactive_protein",
        "label": "C-reactive protein",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 0.1
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "c_reactive_protein",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": null
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "mg/L",
        "value_type": "continuous"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "demographic",
        "field_id": "baseline_current_smoker",
        "label": "Current cigarette smoking",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "current_smoker",
        "source_ids": [],
        "support": {
          "lower": 0.0,
          "upper": 1.0
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "0=no, 1=yes",
        "value_type": "integer"
      },
      {
        "allowed_values": null,
        "categories": [],
        "evidence_role": "mechanism_relative",
        "family": "disease_measure",
        "field_id": "baseline_diagnosis_duration_months",
        "label": "Time since diagnosis",
        "measurement": {
          "artifact_modes": [],
          "device_or_assay": null,
          "error": {
            "error_model": "exact"
          },
          "method": "Protocol-defined baseline assessment",
          "missing_value": "",
          "resolution": 1.0
        },
        "offset": 0.0,
        "role": "covariate",
        "scale": 1.0,
        "settings": [
          "observational",
          "trial"
        ],
        "source_codes": [],
        "source_direction": 1,
        "source_field_id": "diagnosis_duration_months",
        "source_ids": [],
        "support": {
          "lower": 3.0,
          "upper": null
        },
        "timing": {
          "reference": "baseline",
          "repeatable": false,
          "window_unit": null
        },
        "unit": "months",
        "value_type": "integer"
      }
    ],
    "baseline_outcome_intercept": 3.2,
    "baseline_safety_probability": 0.04,
    "candidates": [
      {
        "asset_id": "control",
        "assignment_intercept": 0.0,
        "effect_modifiers": [],
        "outcome_effect": 0.0,
        "regimen_response": null,
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.0
      },
      {
        "asset_id": "mrd-89991",
        "assignment_intercept": 0.0882880668725853,
        "effect_modifiers": [
          {
            "difference_per_sd": -0.1022659525852338,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": -0.1252334803167697,
        "regimen_response": {
          "half_maximal_relative_exposure": 1.7794252620262114,
          "response_half_time_fraction": 0.16334291989770686,
          "safety_log_odds_per_log_exposure": 0.7399097821917228
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": 0.24867805502444856,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.07651632462290725,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": 0.1721617304015413,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.019129081155726813,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": 0.019129081155726813,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": 0.05738724346718044,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": 0.019129081155726813,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": 0.05738724346718044,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": -0.003250570490317391
      },
      {
        "asset_id": "mrd-82213",
        "assignment_intercept": -0.06596499224400527,
        "effect_modifiers": [
          {
            "difference_per_sd": -0.06957841420560341,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": -0.07940501393066032,
        "regimen_response": {
          "half_maximal_relative_exposure": 0.5412300658390697,
          "response_half_time_fraction": 0.17644063287734887,
          "safety_log_odds_per_log_exposure": 0.24514573132725676
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": -0.18580139482061492,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.057169659944804586,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": -0.1286317348758103,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.014292414986201147,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": -0.014292414986201147,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": -0.042877244958603435,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": -0.014292414986201147,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": -0.042877244958603435,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.04244033889301666
      },
      {
        "asset_id": "mrd-60468",
        "assignment_intercept": -0.002686562142393545,
        "effect_modifiers": [
          {
            "difference_per_sd": -0.1271881961455973,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": -0.06722673443038782,
        "regimen_response": {
          "half_maximal_relative_exposure": 0.18489518118251996,
          "response_half_time_fraction": 0.16077964739173742,
          "safety_log_odds_per_log_exposure": 0.2830303021746869
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": -0.007567150034408485,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.002328353856741072,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": -0.0052387961776674125,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.000582088464185268,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": -0.000582088464185268,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": -0.0017462653925558042,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": -0.000582088464185268,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": -0.0017462653925558042,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.0020118560659742437
      },
      {
        "asset_id": "mrd-84607",
        "assignment_intercept": -0.1290373826754653,
        "effect_modifiers": [
          {
            "difference_per_sd": 0.08998290774182242,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": -0.9868003153142977,
        "regimen_response": {
          "half_maximal_relative_exposure": 0.1565351623872664,
          "response_half_time_fraction": 0.19696758747419546,
          "safety_log_odds_per_log_exposure": 0.03040584287111461
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": -0.3634552945358939,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.11183239831873659,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": -0.25162289621715733,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.027958099579684148,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": -0.027958099579684148,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": -0.08387429873905244,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": -0.027958099579684148,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": -0.08387429873905244,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.0034482515496578867
      },
      {
        "asset_id": "mrd-11523",
        "assignment_intercept": -0.11054201167619074,
        "effect_modifiers": [
          {
            "difference_per_sd": -0.0169045634992053,
            "variable_id": "secondary_risk"
          }
        ],
        "outcome_effect": -0.7702951270695672,
        "regimen_response": {
          "half_maximal_relative_exposure": 0.7218202881141447,
          "response_half_time_fraction": 0.2575033665956948,
          "safety_log_odds_per_log_exposure": 0.13417509605696623
        },
        "risk_factor_associations": [
          {
            "log_odds_ratio_per_sd": -0.311359999554604,
            "variable_id": "baseline_risk"
          },
          {
            "log_odds_ratio_per_sd": 0.09580307678603199,
            "variable_id": "age_at_index"
          },
          {
            "log_odds_ratio_per_sd": -0.21555692276857197,
            "variable_id": "secondary_risk"
          },
          {
            "log_odds_ratio_per_sd": -0.023950769196507998,
            "variable_id": "sex_code"
          },
          {
            "log_odds_ratio_per_sd": -0.023950769196507998,
            "variable_id": "body_mass_index"
          },
          {
            "log_odds_ratio_per_sd": -0.07185230758952399,
            "variable_id": "c_reactive_protein"
          },
          {
            "log_odds_ratio_per_sd": -0.023950769196507998,
            "variable_id": "current_smoker"
          },
          {
            "log_odds_ratio_per_sd": -0.0,
            "variable_id": "diagnosis_duration_months_fraction"
          },
          {
            "log_odds_ratio_per_sd": -0.07185230758952399,
            "variable_id": "diagnosis_duration_months"
          },
          {
            "log_odds_ratio_per_sd": 0.0,
            "variable_id": "latent_risk"
          }
        ],
        "safety_risk_difference": 0.02706878569826693
      }
    ],
    "cohort_id": "development.tdw-0537e6457cec",
    "control_asset_id": "control",
    "count_dispersion": null,
    "outcome_context_effects": [
      {
        "coefficients": [
          0.4035799198191533,
          -0.5389668414433152,
          -0.30954830119232074,
          -0.06280689835662845,
          0.16700467028786897,
          0.5310406805288009,
          0.11116290942645383,
          0.09269623257145586,
          0.6582424503191671,
          -0.2583745239125611,
          -0.0537773464773181,
          0.237959422154892,
          -0.1039131664301693,
          -0.029220567767325928,
          0.14688818177807342,
          -0.08972239442506996,
          0.02236660878961321,
          -0.22139449209296497,
          0.24128946389866548,
          -0.22986744391546152,
          0.5344832083102677,
          -0.1272207688759857,
          -0.16108637941157405,
          0.513942612292623,
          0.38326601583124276,
          0.2685655676554507,
          0.5962597547084596,
          -0.07115978679205823,
          0.14347766064028528,
          -0.031190955509017144,
          -0.17259125453058655,
          -0.052051933450598144,
          -0.2199109956848712,
          -0.4395088529295891,
          -0.568067917094144,
          -0.25535584942417455,
          0.0814693312188835,
          0.0034032386548702733,
          -0.19002307577212668,
          0.47975054771068504,
          -0.1493946812929432,
          -0.2875440184921357,
          0.09422774131040301,
          0.026732063892480364,
          -0.06930734744261093,
          0.2940818712663747,
          -0.21471754714885963,
          0.02706291922301527,
          0.21803426279552993,
          -0.4394860028240762,
          -0.0019430158987467443,
          -0.12666907143342923,
          -0.28319339323927695,
          0.4012512380192603,
          0.46841463253524335,
          -0.16821393640835244,
          0.5133208458913447,
          0.17756651828670422,
          0.3778756807774778,
          0.5430899410296232,
          -0.15256298775481386,
          0.4465089277787789,
          0.10889571621234606,
          -0.426977730004356,
          -0.17970217686400175,
          0.01503348980415529,
          0.3359933318219823,
          0.033554553561002405,
          -0.2147641228483893,
          0.3436891466034502,
          -0.28051532594940704,
          0.27575162352947113,
          0.1905614433002751,
          -0.14798424589832268,
          0.18349254984186805,
          -0.29869074266902773,
          -0.3236099920419025,
          -0.4188764510262633,
          -0.07625311729986145,
          0.023547528169254282
        ],
        "effect_id": "site_context",
        "effect_type": "group_varying",
        "grouping_variable": "site_id",
        "input_variable": null,
        "levels": [
          "site_001",
          "site_002",
          "site_003",
          "site_004",
          "site_005",
          "site_006",
          "site_007",
          "site_008",
          "site_009",
          "site_010",
          "site_011",
          "site_012",
          "site_013",
          "site_014",
          "site_015",
          "site_016",
          "site_017",
          "site_018",
          "site_019",
          "site_020",
          "site_021",
          "site_022",
          "site_023",
          "site_024",
          "site_025",
          "site_026",
          "site_027",
          "site_028",
          "site_029",
          "site_030",
          "site_031",
          "site_032",
          "site_033",
          "site_034",
          "site_035",
          "site_036",
          "site_037",
          "site_038",
          "site_039",
          "site_040",
          "site_041",
          "site_042",
          "site_043",
          "site_044",
          "site_045",
          "site_046",
          "site_047",
          "site_048",
          "site_049",
          "site_050",
          "site_051",
          "site_052",
          "site_053",
          "site_054",
          "site_055",
          "site_056",
          "site_057",
          "site_058",
          "site_059",
          "site_060",
          "site_061",
          "site_062",
          "site_063",
          "site_064",
          "site_065",
          "site_066",
          "site_067",
          "site_068",
          "site_069",
          "site_070",
          "site_071",
          "site_072",
          "site_073",
          "site_074",
          "site_075",
          "site_076",
          "site_077",
          "site_078",
          "site_079",
          "site_080"
        ],
        "unit": "outcome unit"
      }
    ],
    "outcome_lower_bound": 0.0,
    "outcome_rounding_increment": 0.01,
    "outcome_standard_deviation": 1.32,
    "outcome_upper_bound": 10.0,
    "participant_count": 4800,
    "random_stream_id": "trialdev_observational_population_v1_tdw_0537e6457cec",
    "risk_factor_correlation_matrix": [
      [
        1.0,
        0.1,
        0.3,
        0.08,
        0.15,
        0.25,
        0.1,
        0.0,
        0.25
      ],
      [
        0.1,
        1.0,
        0.2,
        0.008,
        0.015,
        0.025,
        0.01,
        0.0,
        0.1
      ],
      [
        0.3,
        0.2,
        1.0,
        0.024,
        0.045,
        0.075,
        0.03,
        0.0,
        0.15
      ],
      [
        0.08,
        0.008,
        0.024,
        1.0,
        0.012,
        0.02,
        0.008,
        0.0,
        0.02
      ],
      [
        0.15,
        0.015,
        0.045,
        0.012,
        1.0,
        0.0375,
        0.015,
        0.0,
        0.0375
      ],
      [
        0.25,
        0.025,
        0.075,
        0.02,
        0.0375,
        1.0,
        0.025,
        0.0,
        0.0625
      ],
      [
        0.1,
        0.01,
        0.03,
        0.008,
        0.015,
        0.025,
        1.0,
        0.0,
        0.025
      ],
      [
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0
      ],
      [
        0.25,
        0.1,
        0.15,
        0.02,
        0.0375,
        0.0625,
        0.025,
        0.0,
        1.0
      ]
    ],
    "risk_factor_dependence_scale": "latent",
    "risk_factors": [
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": 2.0,
          "mean": 5.2,
          "standard_deviation": 1.0,
          "upper": 9.0
        },
        "outcome_difference_per_sd": 0.8,
        "role": "measured",
        "safety_log_odds_per_sd": 0.0,
        "unit": "DAS28 points",
        "variable_id": "baseline_risk"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": 18.0,
          "mean": 55.0,
          "standard_deviation": 12.0,
          "upper": 85.0
        },
        "outcome_difference_per_sd": 0.1,
        "role": "measured",
        "safety_log_odds_per_sd": 0.35,
        "unit": "years",
        "variable_id": "age_at_index"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "bernoulli",
          "lower": null,
          "mean": 0.35,
          "standard_deviation": 0.47696960070847283,
          "upper": null
        },
        "outcome_difference_per_sd": 0.25,
        "role": "measured",
        "safety_log_odds_per_sd": 0.3,
        "unit": "indicator",
        "variable_id": "secondary_risk"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "bernoulli",
          "lower": null,
          "mean": 0.8,
          "standard_deviation": 0.39999999999999997,
          "upper": null
        },
        "outcome_difference_per_sd": 0.08,
        "role": "measured",
        "safety_log_odds_per_sd": 0.03,
        "unit": "indicator",
        "variable_id": "sex_code"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": 16.0,
          "mean": 28.0,
          "standard_deviation": 5.0,
          "upper": 50.0
        },
        "outcome_difference_per_sd": 0.08,
        "role": "measured",
        "safety_log_odds_per_sd": 0.1,
        "unit": "kg/m2",
        "variable_id": "body_mass_index"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "log_normal",
          "lower": null,
          "mean": 12.0,
          "standard_deviation": 15.0,
          "upper": null
        },
        "outcome_difference_per_sd": 0.15,
        "role": "measured",
        "safety_log_odds_per_sd": 0.1,
        "unit": "mg/L",
        "variable_id": "c_reactive_protein"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "bernoulli",
          "lower": null,
          "mean": 0.2,
          "standard_deviation": 0.4,
          "upper": null
        },
        "outcome_difference_per_sd": 0.08,
        "role": "measured",
        "safety_log_odds_per_sd": 0.15,
        "unit": "0=no, 1=yes",
        "variable_id": "current_smoker"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "beta",
          "lower": null,
          "mean": 0.20516129032258063,
          "standard_deviation": 0.18686362286581598,
          "upper": null
        },
        "outcome_difference_per_sd": 0.0,
        "role": "latent",
        "safety_log_odds_per_sd": 0.0,
        "unit": "fraction",
        "variable_id": "diagnosis_duration_months_fraction"
      },
      {
        "derivation": {
          "effects": [
            {
              "coefficient": -195.0,
              "effect_id": "minimum_diagnosis_age",
              "effect_type": "main",
              "input_variable": "diagnosis_duration_months_fraction",
              "unit": "months"
            },
            {
              "coefficient": 12.0,
              "effect_id": "eligible_lifetime",
              "effect_type": "interaction",
              "input_variables": [
                "age_at_index",
                "diagnosis_duration_months_fraction"
              ],
              "unit": "months"
            }
          ],
          "hierarchical_effect_correlations": [],
          "inputs": [
            "diagnosis_duration_months_fraction",
            "age_at_index"
          ],
          "learned": null,
          "measurement_model": null,
          "mechanism_id": "diagnosis_duration_months",
          "mechanism_type": "derived_effect",
          "nominal_calibration": null,
          "nominal_logits": null,
          "observation_rule": null,
          "output": "diagnosis_duration_months",
          "output_levels": null,
          "output_unit": "months",
          "parameters": [
            {
              "input_variable": null,
              "parameter_id": "intercept",
              "role": "intercept",
              "source": "fixed",
              "unit": "months",
              "value": 3.0
            }
          ],
          "probability_bounds": null,
          "residual_scale": null,
          "stochastic": false
        },
        "distribution": {
          "family": "normal",
          "lower": null,
          "mean": 98.39999999999999,
          "standard_deviation": 95.64,
          "upper": null
        },
        "outcome_difference_per_sd": 0.165,
        "role": "measured",
        "safety_log_odds_per_sd": 0.1,
        "unit": "months",
        "variable_id": "diagnosis_duration_months"
      },
      {
        "derivation": null,
        "distribution": {
          "family": "normal",
          "lower": null,
          "mean": 0.0,
          "standard_deviation": 1.0,
          "upper": null
        },
        "outcome_difference_per_sd": 0.0,
        "role": "latent",
        "safety_log_odds_per_sd": 0.0,
        "unit": "standardized latent-risk unit",
        "variable_id": "latent_risk"
      }
    ],
    "root_seed": 3243003887314180336,
    "safety_context_effects": [
      {
        "coefficients": [
          0.3821779543741982,
          -0.5103852665182909,
          -0.29313286097757646,
          -0.059476229504383,
          0.15814836201502744,
          0.5028794323189403,
          0.10526790665383885,
          0.0877805232684241,
          0.6233356537113324,
          -0.24467284461416772,
          -0.05092551749746032,
          0.22534036188910225,
          -0.09840261972553911,
          -0.027670992203907126,
          0.13909865698681195,
          -0.08496438866010413,
          0.02118050074773978,
          -0.20965387508803499,
          0.22849381051009987,
          -0.2176775037078234,
          0.5061394018089657,
          -0.12047421295074404,
          -0.1525439198973239,
          0.48668807982255957,
          0.36294130287049503,
          0.2543234542191768,
          0.5646399192314958,
          -0.06738616173490362,
          0.13586899681845196,
          -0.029536889686569263,
          -0.16343868800244937,
          -0.049291603646399756,
          -0.2082490489440068,
          -0.4162015652742321,
          -0.5379431033088484,
          -0.24181425134865012,
          0.07714898789666998,
          0.003222763877718062,
          -0.17994609448118057,
          0.45430923078663354,
          -0.14147223607286288,
          -0.27229547205694665,
          0.08923081563485133,
          0.025314454443636707,
          -0.06563195780550277,
          0.27848662051740025,
          -0.20333101055763222,
          0.025627764415734156,
          0.20647183976849423,
          -0.4161799269167388,
          -0.0018399771768435077,
          -0.11995177219074737,
          -0.2681755617796183,
          0.3799727632758147,
          0.4435744626280713,
          -0.15929350038669737,
          0.4860992858819553,
          0.16815011201392444,
          0.35783681891806607,
          0.5142897168841128,
          -0.14447252628296767,
          0.4228304240329345,
          0.10312094338290347,
          -0.40433497159503407,
          -0.17017251596969862,
          0.014236259284237962,
          0.3181755036193014,
          0.03177514541761591,
          -0.20337511633370198,
          0.32546320701084297,
          -0.2656395132096657,
          0.2611284313726052,
          0.1804559122161696,
          -0.14013659649462373,
          0.1737618843199508,
          -0.2828510820729429,
          -0.30644885610028644,
          -0.3966633058960827,
          -0.07220939138244455,
          0.02229879561482413
        ],
        "effect_id": "site_safety",
        "effect_type": "group_varying",
        "grouping_variable": "site_id",
        "input_variable": null,
        "levels": [
          "site_001",
          "site_002",
          "site_003",
          "site_004",
          "site_005",
          "site_006",
          "site_007",
          "site_008",
          "site_009",
          "site_010",
          "site_011",
          "site_012",
          "site_013",
          "site_014",
          "site_015",
          "site_016",
          "site_017",
          "site_018",
          "site_019",
          "site_020",
          "site_021",
          "site_022",
          "site_023",
          "site_024",
          "site_025",
          "site_026",
          "site_027",
          "site_028",
          "site_029",
          "site_030",
          "site_031",
          "site_032",
          "site_033",
          "site_034",
          "site_035",
          "site_036",
          "site_037",
          "site_038",
          "site_039",
          "site_040",
          "site_041",
          "site_042",
          "site_043",
          "site_044",
          "site_045",
          "site_046",
          "site_047",
          "site_048",
          "site_049",
          "site_050",
          "site_051",
          "site_052",
          "site_053",
          "site_054",
          "site_055",
          "site_056",
          "site_057",
          "site_058",
          "site_059",
          "site_060",
          "site_061",
          "site_062",
          "site_063",
          "site_064",
          "site_065",
          "site_066",
          "site_067",
          "site_068",
          "site_069",
          "site_070",
          "site_071",
          "site_072",
          "site_073",
          "site_074",
          "site_075",
          "site_076",
          "site_077",
          "site_078",
          "site_079",
          "site_080"
        ],
        "unit": "log_odds"
      }
    ]
  },
  "estimands": [
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-89991.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-89991",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-89991.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-89991",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-82213.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-82213",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-82213.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-82213",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-60468.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-60468",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-60468.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-60468",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-84607.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-84607",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-84607.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-84607",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "mean_difference",
      "endpoint_id": "outcome",
      "endpoint_kind": "continuous",
      "estimand_id": "mrd-11523.outcome_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-11523",
      "validation_analysis": null,
      "weighted_log_rank": null
    },
    {
      "analysis_plan": null,
      "analysis_question": null,
      "analysis_routes": [],
      "assessment_time": 168.0,
      "cluster_survival_analysis": null,
      "control_arm": "control",
      "effect_measure": "risk_difference",
      "endpoint_id": "safety_event",
      "endpoint_kind": "binary",
      "estimand_id": "mrd-11523.safety_event_observed_association",
      "excluded_methods": [],
      "group_sequential_plan": null,
      "identification_assumptions": [],
      "identification_status": "point_identified",
      "identified_set": null,
      "longitudinal_time_model": "categorical",
      "planning_question": null,
      "population_eligibility": [],
      "safety_event_ids": [],
      "stepped_wedge_analysis": null,
      "target_population": "equally weighted measured baseline records of all participants in the supplied cohort",
      "treatment_arm": "mrd-11523",
      "validation_analysis": null,
      "weighted_log_rank": null
    }
  ]
}
```

</details>

<details><summary>Prospective response process: exact native definition</summary>

```json
{
  "active_endpoint_observation_probability": 0.9802134067429454,
  "attendance_log_odds_per_baseline_sd": 0.0,
  "attendance_log_odds_per_site_sd": 0.0,
  "endpoint_attendance_probability": 1.0,
  "endpoint_observation_probability": 0.9749351689137853,
  "measurement_error_standard_deviation": 0.0,
  "monotone_dropout": true,
  "observation_log_odds_after_reported_safety_event": 0.0,
  "observation_log_odds_per_baseline_sd": 0.0,
  "observation_log_odds_per_prior_outcome_sd": -0.25,
  "outcome_autocorrelation": 0.6,
  "population_risk_profiles": [
    {
      "mean": 5.95,
      "population": "higher_baseline_risk",
      "standard_deviation": 1.0
    }
  ],
  "randomization_block_size": 4,
  "recurrent_loss_log_hazard_per_baseline_sd": 0.0,
  "recurrent_loss_log_hazard_per_prior_event": 0.0,
  "recurrent_loss_to_follow_up_hazard_per_day": 0.0,
  "safety_endpoint": {
    "event_id": "infection_aesi",
    "events": [
      {
        "category": "infection",
        "coding_system": "Protocol AESI dictionary v1",
        "dictionary_term": "Upper respiratory tract infection",
        "discontinuation_severities": [
          "severe"
        ],
        "event_id": "respiratory_infection",
        "hazard_share": 0.65,
        "medical_code": "Upper respiratory tract infection",
        "resolution_probability_per_contact": 0.8,
        "severity_levels": [
          {
            "level": "mild_or_moderate",
            "probability": 0.98,
            "serious": false,
            "seriousness_criteria": []
          },
          {
            "level": "severe",
            "probability": 0.02,
            "serious": true,
            "seriousness_criteria": [
              "AESHOSP"
            ]
          }
        ]
      },
      {
        "category": "infection",
        "coding_system": "Protocol AESI dictionary v1",
        "dictionary_term": "Urinary tract infection",
        "discontinuation_severities": [
          "severe"
        ],
        "event_id": "urinary_infection",
        "hazard_share": 0.35,
        "medical_code": "Urinary tract infection",
        "resolution_probability_per_contact": 0.6,
        "severity_levels": [
          {
            "level": "mild_or_moderate",
            "probability": 0.95,
            "serious": false,
            "seriousness_criteria": []
          },
          {
            "level": "severe",
            "probability": 0.05,
            "serious": true,
            "seriousness_criteria": [
              "AESHOSP"
            ]
          }
        ]
      }
    ]
  },
  "treatment_discontinuation_risk": 0.08
}
```

</details>
