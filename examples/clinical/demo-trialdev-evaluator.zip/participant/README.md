# TrialDev tasks

Start with `task_index.csv` and the request named for your task. The harness places only that task's declared data and documents in the analysis workspace.

**Evidence analysis:** estimate the protocol-defined observed benefit and safety associations and their uncertainty from the initial cohort. These associations motivate prospective investigation; they do not establish causal treatment effects.

Each regimen needs evidence from the preceding phase before entering exploration or confirmation. A qualifying readout has at least 2 participants with observed outcomes at the planned follow-up in that arm and its control (completed follow-up for recurrent outcomes). This is an evidence requirement, not a significance threshold. You may stop at any time.

Progression and approval are simplified benchmark rules, not regulatory practice. Candidates are distinguished only by the evidence the programme acquires.

**Development:** analyse the initial evidence, design studies through safety, exploration and confirmation, analyse acquired participant records, and decide when to stop or advance. Each task's committee brief states the design limits, budget, timing and sponsor value. Study actions reveal only the accrued evidence; prior observations and costs remain part of the programme.

The canonical raw tasks supply linked participant source files. Paired analysis-ready tasks consolidate the same observations. The task catalogue identifies each presentation.

For either task, write `scratch/analysis.py` or `scratch/analysis.R`, with local supporting modules if needed, to reproduce `scratch/estimates.csv` (`target_id,estimate,lower,upper`). Use the supplied target definitions and 95% intervals, and submit a concise explanatory report. The evaluator replays the code in fresh workspaces. In development, report before acquiring further evidence and explicitly stop or advance to finish.
