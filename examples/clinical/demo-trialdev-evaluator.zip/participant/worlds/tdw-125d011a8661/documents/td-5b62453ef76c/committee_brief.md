# MERIDIAN rheumatoid-arthritis programme: development committee brief

**Ariadne Clinical Research Collaborative**

| Document | Development decision framework |
| --- | --- |
| Document ID | ACRC-DEV-5D197955 |
| Study ID | td-5b62453ef76c |
| Version | 1.0 |
| Owner | Development Governance |
| Status | Approved |
| Effective milestone | Approved before the programme decision cutoff |
| Purpose | Define study-design limits, available resources, sponsor preferences and advancement requirements. |
| Related document classes | Comparative evidence protocol, Study design and accrued readout |

## Decision requested

How should the oral immunomodulatory candidates be advanced as a portfolio as evidence accrues for adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy, within the budget and time limits while weighing clinical benefit and safety under the stated sponsor preferences?

Run the studies you judge worthwhile, then either stop development or advance one compound at one dose to benchmark submission. Stopping is a legitimate decision at any time.

Progression and approval are simplified benchmark rules, not regulatory practice. This fictional sponsor scenario evaluates decisions within the stated resource and study limits.

## Clinical synopsis

Population: adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy. Setting: add-on treatment for rheumatoid arthritis despite conventional therapy.

The baseline and endpoint disease-activity measures are a study-specific composite modelled on DAS28-CRP, on a 0–10 scale recorded to 0.01 points; lower is better. They are not validated DAS28-CRP measurements. Tender/swollen joint counts, patient global assessment and ESR are not supplied, so a component-based score cannot be reconstructed. Baseline CRP is a separate pretreatment laboratory measurement. Its distribution is lognormal truncated to 0 < CRP ≤300 mg/L. The initial endpoint is assessed at Day 168 after treatment initiation; initial participant calendar dates, exposure histories and incident event dates are unavailable. Safety surveillance covers only the listed adverse events of special interest, not a complete safety profile. Severity and regulatory seriousness are distinct clinical concepts; this benchmark's restricted event taxonomy classifies its severe safety events as serious hospitalisations.

The control receives the stated background care; exact background-drug doses, prior treatment stability, diagnostic confirmation and additional exclusion criteria cannot be verified from the supplied fields. Blinding procedures, drug supply and manufacturing activities are not modelled. The early-safety phase is a short evidence-acquisition stage, not efficacy confirmation.

## Resources

| Item | Value |
| --- | --- |
| Development budget | $39.0M; spending plus outstanding follow-up obligations for studies may never exceed it |
| Time horizon | programme day 2,190 (six years, the same for every programme); all studies and the decision happen by then |
| Programme overhead | $15,000 per programme day until the decision; outside the study budget and subtracted separately in sponsor value |

## Portfolio

| Compound | Doses |
| --- | --- |
| `mrd-43480` | standard, intensified |
| `mrd-77765` | standard, intensified |
| `mrd-36710` | standard, intensified |
| `mrd-27164` | standard, intensified |
| `mrd-17886` | standard, intensified |

Candidates are distinguished only by the evidence the programme acquires. No candidate-specific mechanism, pharmacokinetic or prior-safety dossiers are supplied; the common dose choices are benchmark options, not a claim of established clinical dose equivalence.

Doses: standard = 15 mg oral, daily; intensified = 30 mg oral, daily. The control arm, always named `control`, receives standard care.

## Study rules

Each study randomises participants between the control arm and one to six active arms, each a different compound and dose. Active arms are named `<compound>-<dose>` unless you name them. The phase limits, start-up/close-out delays and tariffs are shared fictional scenario assumptions, not empirical development-cost or sample-size recommendations.

| Phase | Needs a readout from | Participants per arm | Follow-up options (days) | Start-up (days) | Close-out (days) |
| --- | --- | --- | --- | --- | --- |
| early safety (`early_safety`) | — | 10–100 | 28, 56 | 60 | 14 |
| exploration (`exploration`) | early safety | 30–1,500 | 84, 168 | 90 | 30 |
| confirmation (`confirmation`) | exploration | 300–3,000 | 168, 336 | 120 | 45 |

- **Evidence before the next phase.** A compound and dose can enter exploration or confirmation only after a readout of the preceding phase with at least 2 participants with observed endpoint outcomes at planned follow-up in its arm and in control (completed follow-up for recurrent outcomes). This simplified benchmark progression rule does not establish adequate safety, precision or clinical phase completion.
- **Visit grid.** Assessments and safety contacts happen on days 28, 56, 84, 168, 336 after enrolment. A study uses the grid days up to its follow-up; you may choose fewer. Readouts contain only assessments and contacts recorded and available at their cutoff; some outcomes are unobserved.
- **Readouts.** One or two per study, each on a deadline you set (a programme day), or earlier once a number of participants you set have their primary outcome recorded at the end of follow-up. One programme clock serves all studies; requesting a readout moves it to that look. Each readout uses one planned look, even an early one with few or no completed participants, and its files never change. A look whose deadline passes while you wait stays available and releases the data as of the day you request it. Studies are numbered by phase (`study-101`, `study-201`, `study-301`, ...) and each readout's files are released in `evidence/<study>-look-<n>/`.
- **Sites.** Between 2 and 139 sites, opened in the order of documents/site_network.csv, the same order for every study. Each site opens on its listed day after study start-up and screens about its listed number of candidates a month.
- **Recruitment.** By default every eligible screened candidate is enrolled. You may accept a smaller share of screened candidates overall (`background_fraction`, 0.1–1) or within the groups below (`screening_fraction`); where groups overlap the larger share applies. About 40% of screened candidates fail screening and are never enrolled. Screened candidates are charged even when not enrolled.

| Group | Description | Definition | Patients in the programme population |
| --- | --- | --- | --- |
| `prior_biologic` | Prior biologic DMARD use | prior_biologic_dmard_use > 0 | 715 |
| `inflammation_longstanding` | CRP at least 10 mg/L and diagnosis for at least five years | baseline_c_reactive_protein ≥ 10 and baseline_diagnosis_duration_months ≥ 60 | 479 |

## Study costs (USD)

| Phase | Set-up | Per site | Per screened candidate | Per enrolled participant | Per participant-day of follow-up | Per visit |
| --- | --- | --- | --- | --- | --- | --- |
| early safety | 1,000,000 | 50,000 | 1,000 | 12,000 | 60 | 1,500 |
| exploration | 2,000,000 | 75,000 | 1,500 | 10,000 | 40 | 600 |
| confirmation | 4,000,000 | 100,000 | 2,000 | 12,000 | 40 | 800 |

A visit is any grid day used for assessment or safety contact. Follow-up and visits not yet completed are committed when a participant enrols and stay owed if a study closes early.

## Approval and sponsor value

**Simplified benchmark approval.** This is a simplified benchmark approval rule, not regulatory practice. At advancement the benchmark reviewer uses fully ascertained frozen outcomes for every participant randomized to the advanced compound/dose or control in confirmation studies whose planned follow-up has elapsed by the programme clock, including outcomes unavailable in participant readouts after observation loss. It applies a two-sided test of benefit at the stated alpha, pooled by inverse variance across studies, and requires at least the stated number of calendar-matured treated participants. Calendar maturity is distinct from observed endpoint completion. This approval is required for benchmark market value. Two-sided alpha 0.05; at least 300 completed participants on the advanced compound and dose. The benchmark reviewer tests the population your confirmation studies enrolled. This is separate from the whole-programme population used for reporting and sponsor value.

**Value.** An approved treatment earns $250M operating profit a year for each 1 DAS28 points by which it lowers study-specific disease-activity composite modelled on DAS28-CRP at the endpoint assessment versus control (lower is better), less $20.8M a year for each percentage point of excess risk of treatment-emergent infection of special interest by the endpoint assessment. These are its true effects in the whole programme population (all comers, whatever population the approval rested on) at day 336. Profit runs from launch, 365 days after the decision, until exclusivity ends on programme day 6,575, discounted at 10% a year to programme day 0. Study costs and programme overhead are subtracted; a stopped programme or a rejected submission earns nothing.

## Programme population

2,048 patients; their baseline characteristics are in data/target_population.parquet. Each study's results are active-minus-control differences over this whole population at the study's follow-up day, whoever the study recruits.
