# MERIDIAN rheumatoid-arthritis programme: comparative evidence analysis

**Ariadne Clinical Research Collaborative**

| Document | Evidence analysis request |
| --- | --- |
| Document ID | ACRC-EREQ-A1AAD89B |
| Study ID | td-484317e14aa2 |
| Version | 1.0 |
| Owner | Clinical Epidemiology and Biostatistics |
| Status | Approved |
| Effective milestone | Issued at the stated evidence cutoff |
| Purpose | State the observational comparison question, available evidence and reporting requirements. |
| Related document classes | Comparative evidence protocol, Statistical reporting standard |

## Decision at this evidence cutoff

What are the protocol-defined observed associations between each oral immunomodulatory candidate and standard care for benefit and safety in adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy, and how uncertain are those estimates?

## Supplied materials

- `data/initial/participants.parquet`: Participant identifiers and measured pretreatment characteristics.
- `data/initial/treatments.parquet`: Observed treatment received, linked by participant_id.
- `data/initial/clinical_assessments.parquet`: Recorded study-specific disease-activity composite modelled on DAS28-CRP at the endpoint assessment, linked by participant_id.
- `data/initial/safety_assessments.parquet`: Recorded treatment-emergent infection of special interest by the endpoint assessment, linked by participant_id.
- `documents/evidence_protocol.md`: Cohort definition, study-specific disease-activity composite modelled on DAS28-CRP at the endpoint assessment, safety endpoint, and available baseline variables.
- `documents/observational_data_dictionary.csv`: Variable definitions, units, timing, roles, and controlled terminology for the cohort.

## Requested work

- Estimate the protocol-defined case-mix standardized observed association for each candidate versus standard care in the study-specific disease-activity composite modelled on DAS28-CRP at the endpoint assessment at Day 168 and in the risk of the treatment-emergent infection of special interest by the endpoint assessment.
- Quantify uncertainty with a 95% interval for each estimate.
- Explain the findings and their implications for prospective development, distinguishing observed associations from causal effects.

## Working requirements

Use the evidence available at the current cutoff. Keep your runnable analysis and supporting files in the writable `scratch/` directory. Explain the findings and uncertainty relevant to the decision.

## Submission

Keep your analysis in scratch/analysis.py or scratch/analysis.R. It reports the current targets with 95% intervals and must reproduce its numbers from the available evidence in a fresh session. Submit a concise report explaining your analysis, findings and uncertainty.
