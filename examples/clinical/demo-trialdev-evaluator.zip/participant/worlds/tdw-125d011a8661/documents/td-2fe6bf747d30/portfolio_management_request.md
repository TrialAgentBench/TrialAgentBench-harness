# MERIDIAN rheumatoid-arthritis programme: sequential development decision

**Ariadne Clinical Research Collaborative**

| Document | Development analysis request |
| --- | --- |
| Document ID | ACRC-DREQ-986077DC |
| Study ID | td-2fe6bf747d30 |
| Version | 1.0 |
| Owner | Development Biostatistics |
| Status | Approved |
| Effective milestone | Issued at the stated evidence cutoff |
| Purpose | State the current development question, available evidence, requested analyses, and decision. |
| Related document classes | Comparative evidence protocol, Development decision framework, Study design and accrued readout |

## Decision at this evidence cutoff

How should the oral immunomodulatory candidates be advanced as a portfolio as evidence accrues for adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy, within the budget and time limits while weighing clinical benefit and safety under the stated sponsor preferences?

## Supplied materials

- `documents/td-2fe6bf747d30/committee_brief.md`: Committee brief: portfolio, study rules and visit grid, costs, budget, horizon, approval rule and sponsor value.
- `documents/site_network.csv`: Recruitment sites in activation order, with opening day, screening rate and capacity.
- `data/observational_cohort.parquet`: The same recorded cohort assessments joined to participant and treatment fields.
- `data/standards.zip`: SDTM/ADaM views of the same observed cohort; no randomization or unrecorded dates are implied.
- `documents/evidence_protocol.md`: Cohort definition, study-specific disease-activity composite modelled on DAS28-CRP at the endpoint assessment, safety endpoint, and available baseline variables.
- `documents/observational_data_dictionary.csv`: Variable definitions, units, timing, roles, and controlled terminology for the cohort.
- `data/target_population.parquet`: Recorded baseline characteristics of the programme population for prospective treatment contrasts.
- `documents/target_population_dictionary.csv`: Clinical fields, recruitment groups, sites and units in the programme population table.

## Requested work

- Analyse the initial comparative evidence and quantify the requested observed associations and uncertainty.
- Design and analyse studies through early safety, exploration and confirmation as useful for the development decision.
- Adapt recruitment, allocation and follow-up using acquired evidence, retaining prior evidence and incurred costs.
- Stop development or advance a candidate and regimen under the stated sponsor preferences.

## Decision workflow

The committee brief states the portfolio, study rules, costs, budget, time horizon and sponsor value. Design and run studies, analyse each readout, and finish by stopping development or advancing one compound and dose. Evidence already acquired stays available and money spent stays spent. Each readout request and the final decision keep your current analysis as your report for that point.

Each study's results are active-minus-control differences over the whole programme population at that study's follow-up day, whoever the study recruits. The baseline characteristics of that population are in data/target_population.parquet (fields in documents/target_population_dictionary.csv); it holds no treatment or outcome records. The initial observational comparisons refer to the initial cohort.

## Working requirements

Use the evidence available at the current cutoff. Keep your runnable analysis and supporting files in the writable `scratch/` directory. Explain the findings and uncertainty relevant to the decision.

## Submission

Keep your analysis in scratch/analysis.py or scratch/analysis.R. It reports the current targets with 95% intervals and must reproduce its numbers from the available evidence in a fresh session. It is rerun at each readout request and at the final decision, and its results are kept as your report for that point.
