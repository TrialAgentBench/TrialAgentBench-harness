# Comparative evidence protocol

**Ariadne Clinical Research Collaborative**

| Document | Comparative evidence protocol |
| --- | --- |
| Document ID | ACRC-CEP-239D7B5B |
| Study ID | tdw-125d011a8661 |
| Version | 1.0 |
| Owner | Clinical Epidemiology and Biostatistics |
| Status | Approved |
| Effective milestone | Approved before cohort extraction |
| Purpose | Define the observational population, contrasts, endpoints, measured covariates, and limitations. |
| Related document classes | Development decision framework, Statistical analysis request |

Programme: MERIDIAN rheumatoid-arthritis programme.

Therapeutic area: rheumatology.

Clinical setting: add-on treatment for rheumatoid arthritis despite conventional therapy.

Population: adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy.

The starting evidence is a stylised nonrandomised benchmark cohort. Candidate treatment labels do not establish routine-care access, licensing, previous phase completion or prior safety evidence. Candidates are distinguished only by the evidence the programme acquires; no candidate-specific mechanism, pharmacokinetic or prior-safety dossiers are supplied.

Compare outcomes among recipients of each candidate with recipients of standard care, standardized to the cohort's overall distribution of the pretreatment characteristics listed below. The comparison population includes all cohort participants, including those receiving other candidates. Report the difference and a 95% confidence interval for this fixed comparison population. These observational comparisons inform which treatments to investigate in randomized studies.

Observational cohort size: 2,400 participants.

The initial cohort contains separate participant, treatment, clinical-assessment and safety-assessment records linked by participant_id. These are complete single-cutoff assessments; the clinical assessment and cumulative safety indicator cover the window defined below. Event dates and longitudinal exposure histories are not recorded.

Treatment contrasts: each candidate versus control, expressed as candidate minus control.

Treatment identifiers: control (standard care); candidates mrd-43480, mrd-77765, mrd-36710, mrd-27164, mrd-17886.

Candidate reference regimen: 15 mg oral, daily. This describes the candidate at its reference dose; treatment in the initial cohort was observed, not assigned by this protocol. Individual administration dates and exposure histories are unavailable.

Safety event types: Upper respiratory tract infection; Urinary tract infection. Count each participant once if any listed event occurs.

Clinical endpoint: study-specific disease-activity composite modelled on DAS28-CRP at the endpoint assessment at Day 168; lower values are favorable. Report the adjusted mean difference, calculated as candidate minus standard care, in DAS28 points.

Clinical interpretation: The benchmark uses 0.6 points as its interpretation scale. For context, the EULAR DAS28 response criteria use within-person changes of 0.6 and 1.2 points ([validation study](https://pmc.ncbi.nlm.nih.gov/articles/PMC2674547/)). These criteria do not validate this study-specific composite or set a required between-group benefit.

The baseline and endpoint disease-activity measures are a study-specific composite modelled on DAS28-CRP, on a 0–10 scale recorded to 0.01 points; lower is better. They are not validated DAS28-CRP measurements. Tender/swollen joint counts, patient global assessment and ESR are not supplied, so a component-based score cannot be reconstructed. Baseline CRP is a separate pretreatment laboratory measurement. Its distribution is lognormal truncated to 0 < CRP ≤300 mg/L. The initial endpoint is assessed at Day 168 after treatment initiation; initial participant calendar dates, exposure histories and incident event dates are unavailable. Safety surveillance covers only the listed adverse events of special interest, not a complete safety profile. Severity and regulatory seriousness are distinct clinical concepts; this benchmark's restricted event taxonomy classifies its severe safety events as serious hospitalisations.

Safety endpoint: treatment-emergent infection of special interest by the endpoint assessment; lower risk is favorable. Report the adjusted risk difference as a difference in proportions.

Available baseline variables: Baseline study-specific disease-activity composite modelled on DAS28-CRP, Age at treatment initiation, Prior biologic DMARD use before baseline, Recorded sex, Body mass index, C-reactive protein, Current cigarette smoking, Time since diagnosis, clinical site and country, measured before treatment assignment.

Prospective treatment policy: safety events recorded as severe end investigational treatment; standard care and outcome follow-up continue. Urgent safety reports are collected independently of scheduled study assessments. Prospective contrasts include outcomes after discontinuation in the originally assigned group.

Additional standard-care rescue therapy may start from Day 98. Rescue adds therapy; follow-up continues in the original treatment group. Treatment-policy outcomes include rescue use; the readout records when rescue began and when it became available in the study data.

