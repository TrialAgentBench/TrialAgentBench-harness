# MERIDIAN rheumatoid-arthritis programme: comparative evidence analysis

**Ariadne Clinical Research Collaborative**

| Document | Development analysis request |
| --- | --- |
| Document ID | ACRC-DREQ-B5A8AF0F |
| Owner | Development Biostatistics |
| Status | Approved |
| Effective milestone | Issued at the stated evidence cutoff |
| Purpose | State the current development question, available evidence, requested analyses, and decision. |
| Related document classes | Comparative evidence protocol, Development decision framework, Study design and accrued readout |

## Decision at this evidence cutoff

What are the protocol-defined observed associations between each oral immunomodulatory candidate and standard care for benefit and safety in adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy, and how uncertain are those estimates?

## Supplied materials

- `data/observational_cohort.parquet`: The same recorded cohort assessments joined to participant and treatment fields.
- `data/standards.zip`: SDTM/ADaM views of the same observed cohort; no randomization or unrecorded dates are implied.
- `documents/evidence_protocol.md`: Cohort definition, Disease Activity Score in 28 joints at the endpoint assessment, safety endpoint, and available baseline variables.
- `documents/observational_data_dictionary.csv`: Variable definitions, units, timing, roles, and controlled terminology for the cohort.

## Requested work

- Estimate the protocol-defined case-mix standardized observed association for each candidate versus standard care in the Disease Activity Score in 28 joints at the endpoint assessment at Day 168 and in the risk of the treatment-emergent infection of special interest by the endpoint assessment.
- Quantify uncertainty with a 95% interval for each estimate.
- Explain the findings and their implications for prospective development, distinguishing observed associations from causal effects.

## Working requirements

Use the evidence available at the current cutoff. Keep your runnable analysis and supporting files in the writable `scratch/` directory. Explain the findings and uncertainty relevant to the decision.

## Submission

Keep your analysis in scratch/analysis.py or scratch/analysis.R. It reports the current targets with 95% intervals and must reproduce its numbers from the available evidence in a fresh session. Submit a concise report explaining your analysis, findings and uncertainty.
