# Comparative evidence protocol

**Ariadne Clinical Research Collaborative**

| Document | Comparative evidence protocol |
| --- | --- |
| Document ID | ACRC-CEP-41EA2AA7 |
| Owner | Clinical Epidemiology and Biostatistics |
| Status | Approved |
| Effective milestone | Approved before cohort extraction |
| Purpose | Define the observational population, contrasts, endpoints, measured covariates, and limitations. |
| Related document classes | Development decision framework, Statistical analysis request |

Programme: MERIDIAN rheumatoid-arthritis programme.

Therapeutic area: rheumatology.

Clinical setting: add-on treatment for rheumatoid arthritis despite conventional therapy.

Population: adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy.

Compare outcomes among recipients of each candidate with recipients of standard care, standardized to the cohort's overall distribution of the pretreatment characteristics listed below. The comparison population includes all cohort participants, including those receiving other candidates. Report the difference and a 95% confidence interval for this fixed comparison population. These observational comparisons inform which treatments to investigate in randomized studies.

Observational cohort size: 300 participants.

The initial cohort contains separate participant, treatment, clinical-assessment and safety-assessment records linked by participant_id. These are complete single-cutoff assessments; the clinical assessment and cumulative safety indicator cover the window defined below. Event dates and longitudinal exposure histories are not recorded.

Treatment contrasts: each candidate versus control, expressed as candidate minus control.

Candidate identifiers: mrd-88811, mrd-93853, mrd-81623; control (standard care).

Candidate reference regimen: 15 mg oral, daily. This describes the candidate at its reference dose; treatment in the initial cohort was observed, not assigned by this protocol. Individual administration dates and exposure histories are unavailable.

Safety event types: Upper respiratory tract infection; Urinary tract infection. Count each participant once if any listed event occurs.

Clinical endpoint: Disease Activity Score in 28 joints at the endpoint assessment at Day 168; lower values are favorable. Report the adjusted mean difference, calculated as candidate minus standard care, in DAS28 points.

Clinical interpretation: A 0.6-point within-person improvement is the lower EULAR moderate-response threshold; it is an interpretation anchor, not a required between-group effect.

Safety endpoint: treatment-emergent infection of special interest by the endpoint assessment; lower risk is favorable. Report the adjusted risk difference as a difference in proportions.

Available baseline variables: Baseline Disease Activity Score in 28 joints, Age at treatment initiation, Prior biologic DMARD use before baseline, Recorded sex, Body mass index, C-reactive protein, Current cigarette smoking, Time since diagnosis, clinical site and country, measured before treatment assignment.

Prospective treatment policy: safety events recorded as severe end investigational treatment; standard care and outcome follow-up continue. Urgent safety reports are collected independently of scheduled study assessments. Prospective contrasts include outcomes after discontinuation in the originally assigned group.

Additional standard-care rescue therapy may start from Day 98. Rescue adds therapy; follow-up continues in the original treatment group. Treatment-policy outcomes include rescue use; the readout records when rescue began and when it became available in the study data.

Prospective recruitment uses the site network in documents/site_network.csv. The requested site count activates sites in the listed order, randomized once for the programme before enrolment. The same order is used in later studies. Sites have different opening dates, forecast rates and candidate capacities; actual screening times vary. Each readout retains participants' site and country. Selecting sites changes recruitment, not the programme population for the requested treatment contrast.

