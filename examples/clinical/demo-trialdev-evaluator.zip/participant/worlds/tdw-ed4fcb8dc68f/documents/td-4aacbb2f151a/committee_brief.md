# MERIDIAN rheumatoid-arthritis programme: development committee brief

**Ariadne Clinical Research Collaborative**

| Document | Development decision framework |
| --- | --- |
| Document ID | ACRC-DEV-EE164DA9 |
| Owner | Development Governance |
| Status | Approved |
| Effective milestone | Approved before the programme decision cutoff |
| Purpose | Define study-design limits, available resources, sponsor preferences and advancement requirements. |
| Related document classes | Comparative evidence protocol, Study design and accrued readout |

## Decision requested

How should the oral immunomodulatory candidates be advanced as a portfolio as evidence accrues for adults with diagnosed rheumatoid arthritis receiving stable background conventional therapy, within the budget and time limits while weighing clinical benefit and safety under the stated sponsor preferences?

Run the studies you judge worthwhile, then either stop development or advance one compound at one dose to regulatory submission. Stopping is a legitimate decision at any time.

## Resources

| Item | Value |
| --- | --- |
| Development budget | $400.0M; spending plus outstanding follow-up obligations may never exceed it |
| Time horizon | programme day 2,190 (six years, the same for every programme); all studies and the decision happen by then |
| Programme overhead | $15,000 per programme day until the decision |

## Portfolio

| Compound | Doses |
| --- | --- |
| `mrd-88811` | standard, intensified |
| `mrd-93853` | standard, intensified |
| `mrd-81623` | standard, intensified |

Doses: standard = 15 mg oral, daily; intensified = 30 mg oral, daily. The control arm, always named `control`, receives standard care.

## Study rules

Each study randomises participants between the control arm and one to six active arms, each a different compound and dose. Active arms are named `<compound>-<dose>` unless you name them.

| Phase | Needs a readout from | Participants per arm | Follow-up options (days) | Start-up (days) | Close-out (days) |
| --- | --- | --- | --- | --- | --- |
| early safety (`early_safety`) | — | 10–100 | 28, 56 | 60 | 14 |
| exploration (`exploration`) | early safety | 30–1,500 | 84, 168 | 90 | 30 |
| confirmation (`confirmation`) | exploration | 300–3,000 | 168, 336 | 120 | 45 |

- **Evidence before the next phase.** A compound and dose can enter exploration or confirmation only after a readout of the preceding phase with at least 2 participants observed in its arm and in control.
- **Visit grid.** Assessments and safety contacts happen on days 28, 56, 84, 168, 336 after enrolment. A study uses the grid days up to its follow-up; you may choose fewer. Participants are lost to follow-up more often after a worse baseline, a worse released result or a reported safety event, so assessing every grid day releases the history a missing-at-random analysis needs.
- **Readouts.** One or two per study, each on a deadline you set (a programme day), or earlier once a number of participants you set have their primary outcome recorded at the end of follow-up. Studies are numbered by phase (`study-101`, `study-201`, `study-301`, ...) and each readout's files are released in `evidence/<study>-look-<n>/`.
- **Sites.** Between 2 and 80 sites, opened in the order of documents/site_network.csv, the same order for every study. Each site opens on its listed day after study start-up and screens about its listed number of candidates a month.
- **Recruitment.** By default every eligible screened candidate is enrolled. You may accept a smaller share of screened candidates overall (`background_fraction`, 0.1–1) or within the groups below (`screening_fraction`); where groups overlap the larger share applies. About 40% of screened candidates fail screening and are never enrolled. Screened candidates are charged even when not enrolled.

| Group | Description | Definition | Patients in the programme population |
| --- | --- | --- | --- |
| `prior_biologic` | Prior biologic DMARD use | prior_biologic_dmard_use > 0 | 173 |
| `inflammation_longstanding` | CRP at least 10 mg/L and diagnosis for at least five years | baseline_c_reactive_protein ≥ 10 and baseline_diagnosis_duration_months ≥ 60 | 118 |

## Study costs (USD)

| Phase | Set-up | Per site | Per screened candidate | Per enrolled participant | Per participant-day of follow-up | Per visit |
| --- | --- | --- | --- | --- | --- | --- |
| early safety | 1,000,000 | 50,000 | 1,000 | 12,000 | 60 | 1,500 |
| exploration | 2,000,000 | 75,000 | 1,500 | 10,000 | 40 | 600 |
| confirmation | 4,000,000 | 100,000 | 2,000 | 12,000 | 40 | 800 |

A visit is any grid day used for assessment or safety contact. Follow-up and visits not yet completed are committed when a participant enrols and stay owed if a study closes early.

## Approval and sponsor value

**Approval.** At advancement the regulator analyses every patient randomized to the advanced asset/regimen or control in this programme's confirmation studies whose committed follow-up has completed: a two-sided test of benefit at the stated alpha, pooled by inverse variance across studies, and at least the stated number of completed treated patients. Approval is required for any market value. Two-sided alpha 0.05; at least 300 completed participants on the advanced compound and dose. The regulator tests the population your confirmation studies enrolled: a confirmation recruited from one group is judged on that group's contrast, which can differ from, and occasionally reverse, the contrast in the whole programme population.

**Value.** An approved treatment earns $250M operating profit a year for each 1 DAS28 points by which it lowers Disease Activity Score in 28 joints at the endpoint assessment versus control (lower is better), less $20.8M a year for each percentage point of excess risk of treatment-emergent infection of special interest by the endpoint assessment. These are its true effects in the whole programme population (all comers, whatever population the approval rested on) at day 336. Profit runs from launch, 365 days after the decision, until exclusivity ends on programme day 6,575, discounted at 10% a year to programme day 0. Study costs and programme overhead are subtracted; a stopped programme or a rejected submission earns nothing.

## Programme population

512 patients; their baseline characteristics are in data/target_population.parquet. Each study's results are active-minus-control differences over this whole population at the study's follow-up day, whoever the study recruits.
